# Architecture

## Purpose

Gym Trainer is structured around a simple rule: UI code presents decisions, domain code makes workout-planning decisions, and data code defines the facts that those decisions use.

The generator is deliberately independent from React and Prisma. That separation keeps algorithm tests fast and prevents UI changes from silently changing workout logic.

## Layers

### Presentation layer

`src/app` contains routes and `src/components` contains reusable UI. Client components manage onboarding interactions, local workout entry, theme selection, and charts.

Key presentation areas:

- `components/onboarding` - preference wizard
- `components/body-map` - accessible custom SVG muscle selector
- `components/program` - dashboard and generated plan
- `components/workout` - active workout logging
- `components/exercises` - exercise library, animated movement guides, and technique instructions
- `components/progress` - progress analytics
- `components/settings` - appearance and preference management

### Domain layer

`src/lib/workout-generator` owns all workout-generation decisions.

- `equipment.ts` resolves usable equipment
- `split-selector.ts` selects weekly structure
- `exercise-filter.ts` applies hard constraints
- `exercise-scorer.ts` ranks only eligible exercises
- `duration.ts` estimates workout length
- `generator.ts` orchestrates selection and creates the plan
- `validation.ts` verifies generator output

`src/lib/progression` contains double-progression rules and is independent from the generator.

### Configuration layer

`src/config/workout.ts` contains generator tuning values. Priority multipliers, score weights, target durations, exercise counts, and time assumptions are centralized instead of being scattered through components.

### Data layer

The curated source dataset is in `src/data`. It allows the rule engine and tests to run without database access.

The normalized production data model is in `prisma/schema.prisma`, and `prisma/seed.ts` imports the same curated exercise dataset into PostgreSQL. This prevents the seed and algorithm fixture from becoming two unrelated sources.

### Persistence

The core MVP uses browser storage for profile, active plan, sessions, and theme. This matches the specification's allowance for local persistence before authentication and makes onboarding-to-progress usable immediately.

PostgreSQL and Prisma are included as the persistent relational foundation. Once authentication is added, user-owned profile, plan, and workout session operations can move behind server-side routes without rewriting the generator.

## Data Flow

### Program generation

```text
Onboarding UI
  -> POST /api/generate
  -> Zod validation
  -> UserProfile
  -> resolveAvailableEquipment
  -> selectSplit
  -> filterEligibleExercises
  -> scoreExercise
  -> exercise selection
  -> prescription
  -> duration adjustment
  -> validateGeneratedPlan
  -> WorkoutPlan
  -> local persistence
  -> Program UI
```

### Workout logging

```text
WorkoutPlan day
  -> Workout Session UI
  -> set values and completion
  -> progression recommendation
  -> WorkoutSessionLog
  -> local persistence
  -> Dashboard / Progress
```

## Client and Server Boundaries

Most application screens are server route components that render client feature components. Interactive screens opt into client execution only where browser state, local storage, charts, or keyboard interaction require it. Program generation crosses a server boundary through `POST /api/generate`, where Zod validates the profile before domain logic runs.

The Prisma client lives under `src/lib/db` and must only be imported by server-side code when server persistence is introduced. It is not imported into interactive client components.

## Determinism

A workout plan is determined by:

- user profile
- available equipment
- exercise dataset
- generator configuration
- generator version

Exercise selection contains no random-number calls. A deterministic day factor can change ordering between Full Body A/B/C while still producing the same result for identical inputs.

## Generator Versioning

Generated plans store `generatorVersion`. This makes it possible to explain why an older plan differs from a plan generated after algorithm changes and creates a path for future migration or comparison tooling.

## Error Strategy

The generator throws controlled user-facing errors when it cannot construct a valid plan. Validation occurs after selection so invalid equipment, empty days, duplicate exercises, invalid prescriptions, or missing required structure are detected before the plan is stored.

UI screens include empty states for missing plans or missing workout history. Internal stack traces are not displayed to users.

## Security Model

The current local-first MVP stores no secrets in the browser. Database secrets stay in `DATABASE_URL` and `.env` is ignored by Git.

When authentication is added, the server layer must validate all enum values, verify record ownership, reject client-supplied user ownership, and authorize every user-specific plan/session mutation.

## Responsive Strategy

The application is mobile-first. Desktop uses a sidebar while mobile uses bottom navigation. Workout logging is optimized for narrow screens because the primary real-world use case is interacting with the application during a training session.
