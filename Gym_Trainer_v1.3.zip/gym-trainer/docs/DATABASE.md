# Database

## Overview

The repository includes a normalized PostgreSQL schema managed through Prisma. The schema supports the complete product domain: user preferences, exercise metadata, generated plans, workout sessions, and set logs.

## Models

### User and profile

`User` owns a `Profile`, workout plans, and workout sessions.

`Profile` stores:

- goal
- experience
- training location
- days per week
- target session duration

Equipment and muscle preferences are normalized into relation tables rather than comma-separated strings.

### Exercise catalog

`Exercise` stores stable identity and core metadata.

Relations provide:

- primary and secondary muscles
- muscle contribution weight
- required/optional equipment
- compatible goals
- compatible locations

Muscles and equipment use stable codes so seed relations do not depend on generated numeric IDs.

### Generated plans

`WorkoutPlan` stores generator version, goal, training frequency, weekly time estimate, creation time, and active state.

`WorkoutDay` contains ordered `WorkoutExercise` rows. Workout exercise rows snapshot sets, rep range, and rest prescription so an existing plan remains understandable even when generator defaults later change.

### Workout history

`WorkoutSession` records start/completion time and duration. `ExerciseSetLog` records set number, nullable weight, reps, and completion state.

A nullable weight supports bodyweight work without incorrectly storing bodyweight as `0 kg`.

## Seed Pipeline

`prisma/seed.ts` imports the curated TypeScript dataset and performs the seed in this order:

1. muscles
2. equipment
3. exercises
4. exercise-muscle relations
5. exercise-equipment relations
6. exercise-goal relations
7. exercise-location relations

The current application dataset contains 134 exercises.

Exercise slugs and stable data codes are unique. Re-running the seed updates existing exercise records and rebuilds normalized relations, making development seeding predictable.

## Local PostgreSQL

Start the included database service:

```bash
docker compose up -d
```

Copy environment configuration:

```bash
cp .env.example .env
```

Generate the client:

```bash
npm run db:generate
```

Create the initial development migration:

```bash
npm run db:migrate -- --name init
```

Seed data:

```bash
npm run db:seed
```

Open Prisma Studio:

```bash
npm run db:studio
```

## Production Migration

After committed migrations exist, production uses:

```bash
npm run db:deploy
```

The production `DATABASE_URL` should come from the deployment platform's secret/environment system and must never be committed.

## Indexing

The schema adds indexes to relation fields used for exercise filtering and user-owned plan/session lookups. This is enough for the expected database size without adding a separate cache layer.

## Runtime Persistence Strategy

The interactive MVP currently uses browser persistence so the full product can be demonstrated without authentication or a database dependency. The PostgreSQL schema is the target user-account persistence model.

When account persistence is enabled, server-side mutations should:

1. derive the user ID from authenticated server context
2. validate all incoming enums and numbers
3. verify ownership of plans and sessions
4. persist generated plan snapshots
5. keep workout history when rebuilding a program
6. never trust a client-supplied user ID
