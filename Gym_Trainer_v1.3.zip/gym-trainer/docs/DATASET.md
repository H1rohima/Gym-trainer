# Exercise Dataset

## Size

The curated application dataset contains **134 exercises**, which sits inside the specification target of approximately 120-150 exercises.

## Equipment Coverage

An exercise can require more than one item, so counts overlap.

| Equipment | Exercises using it |
| --- | ---: |
| Bodyweight | 37 |
| Dumbbell | 30 |
| Machine | 16 |
| Barbell | 15 |
| Bench | 14 |
| Cable | 14 |
| Kettlebell | 12 |
| Resistance Bands | 10 |
| Pull-Up Bar | 7 |

## Primary Muscle Coverage

| Primary muscle | Exercise count |
| --- | ---: |
| Quads | 24 |
| Chest | 16 |
| Lats | 12 |
| Glutes | 10 |
| Triceps | 10 |
| Abs | 9 |
| Biceps | 9 |
| Front Delts | 8 |
| Upper Back | 8 |
| Hamstrings | 6 |
| Obliques | 5 |
| Rear Delts | 5 |
| Calves | 4 |
| Forearms | 3 |
| Side Delts | 3 |
| Lower Back | 2 |

Lower counts for smaller or supporting muscle categories are intentional. The generator also accounts for secondary-muscle contributions, so primary-exercise count is not the same as total training coverage.

## Record Quality Rules

Every exercise is checked for:

- unique stable ID
- unique slug
- unique name
- at least one primary muscle
- at least one required equipment category
- compatible goal metadata
- compatible location metadata
- valid set range
- valid rep range
- at least three concise instruction steps

The current dataset passes these checks with zero validation errors.

## Supported Home Scenarios

The dataset is designed to produce complete plans for:

- no-equipment training
- dumbbell-only training
- dumbbell + pull-up-bar training
- kettlebell-only training
- combinations that include a bench or resistance bands

Gym presets expand the candidate pool to barbell, cable, and machine work.

## Data Ownership

`src/data/exercises.ts` is the curated source dataset used by the domain generator and tests. `prisma/seed.ts` imports the same records into PostgreSQL, avoiding a second manually maintained exercise catalog.
