# Dependency Rationale

The project keeps the dependency set intentionally small. Each major package has a specific responsibility.

| Dependency | Purpose | Why it is used |
| --- | --- | --- |
| Next.js | Application framework | Provides routing, server endpoints, React rendering, build tooling, and deployment compatibility in one framework. |
| React | UI runtime | Powers interactive onboarding, logging, settings, and progress screens. |
| Tailwind CSS | Styling foundation | Provides the requested styling stack while the product-specific design system remains in `globals.css`. |
| Prisma | ORM and schema tooling | Defines the relational model, migrations, generated database client, and seed workflow. |
| `@prisma/adapter-pg` | PostgreSQL driver adapter | Prisma 7 requires a driver adapter for direct PostgreSQL connections. |
| `pg` | PostgreSQL driver | Supplies the PostgreSQL connection used by the Prisma adapter. |
| Zod | Server input validation | Validates onboarding preferences at the `/api/generate` boundary before the generator receives them. |
| Recharts | Progress visualization | Renders the exercise-progression chart without adding a larger analytics framework. |
| Vitest | Unit testing | Runs fast domain tests for generator constraints and progression behavior. |
| `tsx` | TypeScript execution | Runs the Prisma seed script directly. |
| dotenv | Environment loading | Loads `DATABASE_URL` for Prisma CLI configuration and seeding. |

Redux, a form framework, animation libraries, component suites, authentication providers, and caching libraries are intentionally not included because the current product does not need them.
