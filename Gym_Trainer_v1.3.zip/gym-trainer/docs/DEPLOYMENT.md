# Deployment

## Recommended Architecture

- Application: Vercel
- Database: managed PostgreSQL
- ORM: Prisma

## Pre-Deployment Checks

Run locally:

```bash
npm run typecheck
npm run test
npm run lint
npm run build
```

If PostgreSQL persistence is being deployed, also verify:

```bash
npm run db:generate
npm run db:deploy
npm run db:seed
```

Production seed behavior should be reviewed before repeatedly seeding an existing user database.

## Vercel

1. Push the repository to GitHub.
2. Import the repository into Vercel.
3. Keep the framework preset as Next.js.
4. Add `DATABASE_URL` when Prisma/PostgreSQL is used in production.
5. Deploy.

The core local-first application does not require a database connection to render or generate a workout plan.

## Managed PostgreSQL

Create a PostgreSQL database with a provider that supplies a standard connection string.

Set the production secret:

```text
DATABASE_URL=postgresql://...
```

Do not copy local Docker credentials to production.

## Migrations

Development creates migrations with:

```bash
npm run db:migrate -- --name migration-name
```

Production applies committed migrations with:

```bash
npm run db:deploy
```

Do not run development migration commands against production.

## Build Environment

The deployment platform should use a current Node.js 22 runtime. Install dependencies from `package.json`, generate Prisma client code when database-backed server code is enabled, and run the standard Next.js production build.

## Environment Security

- Keep `.env` out of Git.
- Store production secrets in the hosting platform.
- Never expose `DATABASE_URL` through a `NEXT_PUBLIC_` variable.
- Keep user-specific database operations server-side after authentication is added.

## Post-Deployment Smoke Test

Verify:

1. landing page loads
2. onboarding completes on mobile width
3. no-equipment plan generation works
4. dumbbell + pull-up-bar generation works
5. program page loads after generation
6. workout set entry works
7. completed workout appears in Progress
8. exercise library search works
9. theme selection persists
10. browser console has no unexpected runtime errors
