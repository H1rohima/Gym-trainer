# Development Guide

## Requirements

- Node.js 22+
- npm
- Docker Desktop for the included PostgreSQL service

## Setup

```bash
npm install
cp .env.example .env
docker compose up -d
npm run db:generate
npm run db:migrate -- --name init
npm run db:seed
npm run dev
```

The application is available at `http://localhost:3000`.

## Useful Commands

```bash
npm run dev
npm run build
npm run start
npm run lint
npm run typecheck
npm run typecheck:core
npm run test
npm run test:watch
npm run db:generate
npm run db:migrate -- --name change-name
npm run db:seed
npm run db:studio
npm run db:deploy
```

## Development Workflow

For generator changes:

1. change configuration or one domain module
2. run `npm run typecheck:core`
3. run `npm run test`
4. inspect coverage scenarios
5. manually generate at least one affected profile

For UI changes:

1. run `npm run dev`
2. inspect desktop and mobile layouts
3. keyboard-test interactive controls
4. run `npm run typecheck`
5. run `npm run lint`

For exercise data changes:

1. use a stable unique ID and slug
2. verify primary and secondary muscles
3. verify every required equipment item
4. verify location compatibility
5. verify movement pattern and difficulty
6. verify set/rep/rest defaults
7. run generator coverage tests
8. run the Prisma seed when database data must be refreshed

## Adding an Exercise

Add the exercise to `src/data/exercises.ts` with complete metadata. Do not add a record only to increase the database count.

A useful exercise record must include:

- stable ID
- slug
- real display name
- concise description
- instructions
- tips
- difficulty
- movement pattern
- unilateral/compound flags
- primary muscles
- secondary muscles
- required equipment
- compatible goals
- compatible locations
- set range
- rep range
- default rest

## Changing Generator Weights

Change tuning values only in `src/config/workout.ts` unless the behavior is structural. A scoring coefficient is an implementation parameter, not a scientific claim.

After changing a weight, run all generator tests and compare representative profiles rather than validating only one plan.

## Adding a Muscle UI Region

The body-map UI uses stable codes and maps several visual paths to one logical onboarding muscle group when appropriate. Keep database identity separate from raw SVG path IDs.

## Server Generation

Onboarding posts a profile to `POST /api/generate`. The route validates the request with Zod, calls the deterministic generator on the server, and returns a `WorkoutPlan`. This keeps the main algorithm out of the browser bundle and provides a real server-side input-validation boundary.

## Browser Storage

The local MVP storage adapter is `src/lib/storage.ts`.

It stores:

- profile
- active plan
- workout sessions
- appearance preference

Deleting browser site data resets the local demo state.

## Database Development

The included Docker service uses the development credentials from `.env.example`. They are safe only for local development.

After changing `prisma/schema.prisma`:

```bash
npm run db:migrate -- --name describe-change
npm run db:generate
```

Then update the seed if new required entities or relations were introduced.

## Code Style

The codebase uses strict TypeScript and descriptive function/type names. Workout-generation decisions must stay outside React components.

Implementation source files intentionally contain no explanatory inline comments. Architectural reasoning and behavior documentation live in the repository documentation instead.

## Troubleshooting

### Prisma cannot connect

Verify Docker is running and `docker compose ps` shows PostgreSQL as healthy. Confirm `DATABASE_URL` matches the local service.

### Program generation fails

Review the selected environment and equipment. The generator does not relax required-equipment rules to create a plan.

### No workout history appears

Complete and finish a workout session. In the local MVP, history is stored in the current browser profile.

### Theme appears incorrect after manual storage edits

Return to Settings and select Light, Dark, or System again so the theme adapter rewrites the valid preference.
