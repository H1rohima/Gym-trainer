# Workout Generator

## Goal

The generator creates a practical weekly workout plan from structured profile data without AI, machine learning, external recommendation services, or uncontrolled randomness.

Its most important correctness rule is equipment compatibility: every selected exercise must be possible with the user's available equipment.

## Input

A `UserProfile` contains:

- goal
- experience level
- training location
- selected home equipment or gym preset
- days per week
- session-duration category
- muscle priorities

Supported goals:

- `HYPERTROPHY`
- `STRENGTH`
- `GENERAL_FITNESS`

Supported training frequencies are 1-7 days per week.

## Pipeline

```text
UserProfile
  -> Resolve equipment
  -> Filter eligible exercise pool
  -> Select weekly split
  -> Score exercises for each day
  -> Select a diverse set of movements
  -> Apply sets, reps, and rest prescription
  -> Estimate duration
  -> Trim lower-value work when necessary
  -> Validate the complete plan
  -> WorkoutPlan
```

## Equipment Resolution

Bodyweight is always available.

Home profiles add only explicitly selected equipment. Selecting `NO_EQUIPMENT` resolves to bodyweight only.

Gym presets expand to predefined equipment sets:

- Basic Gym: bodyweight, pull-up bar, dumbbells, barbell, bench, cable
- Full Gym: Basic Gym plus kettlebells and machines

An exercise is eligible only when every required equipment item is available.

```text
requiredEquipment subsetOf availableEquipment
```

The generator never treats a required bench, cable station, barbell, or machine as optional to obtain more matches.

## Hard Filtering

Before scoring, an exercise must satisfy all applicable hard constraints:

1. It is active.
2. Its location supports the user's training environment.
3. Every required equipment item is available.
4. Its difficulty is compatible with the user's experience.
5. It supports the selected goal.

Scoring is not allowed to override these rules.

## Split Selection

### 1 day

- Full Body

### 2 days

- Full Body A
- Full Body B

### 3 days

Default:

- Full Body A
- Full Body B
- Full Body C

When the profile contains several high-priority upper-body muscle groups:

- Upper
- Lower + Core
- Full Body

### 4 days

- Upper A
- Lower A
- Upper B
- Lower B

### 5 days

- Push
- Pull
- Legs
- Upper
- Lower + Core

### 6 days

- Push A
- Pull A
- Legs A
- Push B
- Pull B
- Legs B

### 7 days

- Push
- Pull
- Legs
- Upper
- Lower + Core
- Full Body A
- Full Body B

Higher-frequency plans use a smaller exercise-count target per session so weekly workload does not simply scale linearly with training frequency. The rules remain deterministic and inspectable in `split-selector.ts` and `src/config/workout.ts`.

## Muscle Priorities

Muscle priorities are relative planning weights:

- Low
- Medium
- High

The coefficients are configuration parameters. They are not presented as biological claims.

When no muscle is manually prioritized, the generator can still construct a balanced program.

## Exercise Scoring

Only eligible exercises are scored. Scoring considers:

- primary target-muscle match
- secondary-muscle usefulness
- selected priority level
- compound movement value
- movement-pattern diversity
- duplicate-pattern penalty
- session-length efficiency
- equipment simplicity

All scoring values are centralized in `src/config/workout.ts`.

## Movement Diversity

The exercise database includes movement patterns such as:

- horizontal push
- vertical push
- horizontal pull
- vertical pull
- squat
- hinge
- lunge
- elbow flexion
- elbow extension
- shoulder abduction
- core flexion
- core stability
- carry
- calf raise

As exercises are selected, already-used patterns influence later scores. This reduces sessions that contain several near-identical movements when useful alternatives exist.

## Deterministic Day Variation

Full-body templates can have the same focus muscles. Without another deterministic signal, their ranked exercise lists would be identical.

The generator therefore adds a small reproducible day-specific ordering factor derived from the exercise ID and day index. It contains no randomness and never bypasses hard constraints. Its purpose is only to break close scores differently across weekly days. A weekly repeat penalty also encourages useful variation without forbidding repeated foundational movements.

## Prescription

Each selected exercise receives:

- set count
- minimum reps
- maximum reps
- rest seconds
- estimated minutes

Exercise metadata defines safe/default boundaries. Goal-specific rules adjust within those boundaries.

Strength programs use lower ranges for suitable compound movements and longer compound rest periods. Hypertrophy and general-fitness programs use moderate rep ranges while respecting exercise-specific limits.

## Duration Estimation

The estimate uses active set time, between-set rest, and an exercise transition allowance.

```text
exercise duration =
  sets * active set seconds
  + (sets - 1) * rest seconds
  + transition allowance
```

If a generated session substantially exceeds the target, the generator removes lower-value work before removing essential structure. It does not attempt to match an exact minute value.

## Explanation Generation

Every generated exercise contains a short `reason` built from exercise metadata and profile state.

An explanation can mention:

- a high-priority target muscle
- the main muscle group
- compatible available equipment
- the movement pattern

This explanation is template-based and deterministic. It is not generated by an LLM.

## Validation

After construction, the validator checks:

- required equipment remains available
- every day contains exercises
- no exercise is duplicated within a day
- set counts are valid
- rep ranges are valid
- exercise order values are valid
- all generated days are structurally complete

Validation errors prevent the plan from being stored.

## Progression

The MVP uses double progression.

For an exercise such as `3 x 8-12`:

- all completed sets reach 12 reps -> `INCREASE_LOAD`
- performance remains inside the target -> `KEEP_LOAD`
- any completed set falls below 8 -> `REDUCE_LOAD`
- insufficient data -> `NO_RECOMMENDATION`

The application does not invent an exact next weight because available load increments are unknown.

## Extending the Generator

Future deterministic features can be added without changing the architecture:

- exercise substitution
- exact equipment increments
- custom exclusions
- controlled seeded alternatives
- custom splits
- deload rules

Any future replacement system should preserve primary muscle, movement pattern, equipment compatibility, difficulty, exercise role, and rep suitability.
