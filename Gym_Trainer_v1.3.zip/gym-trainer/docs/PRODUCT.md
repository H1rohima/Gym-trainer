# Product Scope

## Product

**Gym Trainer**

Subtitle: **Build a workout that fits you.**

The application creates a practical workout program from the user's goal, experience, training location, available equipment, muscle priorities, weekly frequency, and session length.

## Target User

The primary user is a beginner or intermediate home/gym trainee who wants a sensible plan without configuring advanced periodization concepts.

The onboarding experience is designed to take approximately one to two minutes.

## MVP Decisions

### Included

- Muscle Growth, Strength, and General Fitness goals
- Home and Gym environments
- Home equipment selection
- Basic Gym and Full Gym presets
- Beginner, Intermediate, and Advanced experience
- Interactive muscle selection
- Low/Medium/High muscle priority with visible color intensity on the body map
- 1-7 training days
- four session-duration categories
- deterministic program generation
- program review
- active workout logging
- progression recommendation
- progress metrics
- exercise library
- embedded YouTube technique videos and step-by-step technique instructions
- light/dark/system appearance

### Intentionally excluded from the MVP

- AI coach
- chatbot or LLM integration
- machine learning
- nutrition tracker
- meal generation
- social network features
- friends and messaging
- marketplace
- subscriptions and payments
- advertising
- wearable integrations
- Apple Health / Google Fit
- native mobile apps
- medical or rehabilitation recommendations
- complex injury management
- achievement economy

A focused and explainable training product is preferred over a broad set of unfinished features.

## Safety Scope

Gym Trainer is a general fitness planning tool, not medical software. It does not diagnose conditions, provide rehabilitation, guarantee muscle growth or weight loss, or claim medical suitability.

Exercise instructions are short, general, and conservative.

## UX Principles

- one clear primary action per screen
- visual selection for important decisions
- minimal fitness jargon
- strong typography and whitespace
- limited settings
- restrained visual design
- mobile-first workout logging
- visible selected states beyond color alone
- useful empty and error states

## Visual Direction

The interface is clean and product-oriented rather than a neon bodybuilding theme. It uses rounded cards, subtle borders/shadows, a restrained accent, responsive spacing, and designed light/dark themes.

## Success Criteria

A completed core product should allow a new user to:

1. open the application
2. choose a goal
3. choose Home or Gym
4. select equipment
5. select experience
6. select muscles and priorities
7. choose frequency and duration
8. review preferences
9. generate a valid program
10. inspect the weekly plan
11. understand why exercises were selected
12. start a workout
13. log sets
14. finish the workout
15. see history and progress

At no point may the plan contain an exercise whose required equipment is unavailable.
