# Testing

## Strategy

The highest-value tests target the deterministic domain layer because generator correctness is more important than snapshotting presentation markup.

## Commands

Full project type check:

```bash
npm run typecheck
```

Domain-only strict TypeScript check:

```bash
npm run typecheck:core
```

Unit and coverage tests:

```bash
npm run test
```

Lint:

```bash
npm run lint
```

Production build:

```bash
npm run build
```

## Generator Tests

`tests/generator/generator.test.ts` checks:

- identical profiles generate identical program content
- unavailable equipment is never selected
- no-equipment profiles only receive bodyweight-compatible work
- long-session profiles produce more planned work than short-session profiles under comparable conditions
- beginners do not receive excluded advanced exercises
- every supported 1-7 day frequency produces the correct number of workout days

## Coverage Scenarios

`tests/generator/coverage.test.ts` represents the specification's key equipment combinations.

### Scenario A

- Home
- No equipment
- 1 day
- General Fitness

Expected: a valid full-body program.

### Scenario B

- Home
- Dumbbells
- 3 days
- Muscle Growth

Expected: a valid program using only available equipment.

### Scenario C

- Home
- Dumbbells + Pull-Up Bar
- 4 days
- Muscle Growth

Expected: valid pushing and pulling options.

### Scenario D

- Home
- Kettlebell
- 3 days
- General Fitness

Expected: a valid program.

### Scenario E

- Gym
- Full Gym
- 4 days
- Muscle Growth

Expected: a valid program with broad exercise choice.

### Scenario F

- Gym
- Full Gym
- 3 days
- Strength

Expected: a valid strength-oriented program.

## Progression Tests

`tests/progression/progression.test.ts` checks:

- top of the rep range across all completed sets -> increase load
- valid but incomplete progression -> keep load
- reps below minimum -> reduce load
- insufficient data -> no recommendation

## Manual Acceptance Checklist

### Onboarding

- Goal can be selected.
- Home and Gym produce different equipment choices.
- `No Equipment` deselects other home equipment and vice versa.
- Body-map regions work with mouse and keyboard.
- Muscle priorities can be changed.
- Frequency supports 1 through 7 days.
- Duration supports all four product categories.
- Review shows the chosen settings.

### Program

- Building a program navigates to the program screen.
- Every day contains exercises.
- Exercise reasons are visible.
- Program exercise equipment is compatible with the profile.
- Regenerating the same profile produces the same plan content.

### Workout

- A selected plan day starts correctly.
- Weight can remain blank for bodyweight work.
- Reps and completion state can be entered per set.
- Previous performance appears after a prior session exists.
- Rest timer is non-blocking.
- Finishing the workout saves a session.

### Progress

- Completed workout count updates.
- Weekly count updates.
- Set totals update.
- Exercise history can be selected.
- Progress chart renders when history exists.

### Responsive UI

Check at approximately:

- 375 px mobile width
- tablet width
- desktop width

Verify the mobile bottom navigation and desktop sidebar do not overlap content.

## Important Invariants

Any future generator modification should retain tests for these invariants:

- hard equipment constraints cannot be bypassed
- no empty workout day
- no accidental duplicate exercise inside one session
- supported day counts always work
- beginner filtering remains conservative
- generated prescriptions remain valid
- deterministic input produces deterministic content

### Additional high-frequency coverage

The coverage suite also verifies:

- Full Gym - 6 days - Muscle Growth
- Full Gym - 7 days - General Fitness

These scenarios ensure the extended frequency range produces the requested number of valid workout days while still respecting equipment and duration constraints.
