# Version 1.3 Updates

This revision finishes the media layer of Gym Trainer while preserving the existing visual design.

## Body Map Priority Intensity

The selected muscle color now reflects priority directly on the body map.

- Low uses the lightest selected shade.
- Medium uses a stronger shade.
- High uses the darkest selected shade.

The change is immediate when the user changes a muscle priority.

## Training Frequency

The onboarding flow supports 1-7 training days per week. The deterministic workout generator contains valid split rules for every supported frequency and reduces per-session exercise count for higher-frequency schedules where appropriate.

## Video Demonstrations for the Full Exercise Library

Every exercise detail view now requests an embedded YouTube technique demonstration. Videos are streamed through YouTube's privacy-enhanced embed domain and are never downloaded into the project.

The resolver works in this order:

1. Use a locally curated video when one exists.
2. Match the exercise against public exercise indexes that contain YouTube tutorial references.
3. Prefer exact exercise names and aliases.
4. Use equipment and primary-muscle metadata to improve close matches.
5. Clearly label a close variation as a related technique demonstration.
6. Keep a direct YouTube search as a network or source-availability backup.

The external indexes currently used are:

- exercemus/exercises
- rthepen/workout-database

No YouTube API key is required.

## Technique Guidance

Written technique remains the source of truth for the exact exercise variation. Each exercise keeps:

- a short overview;
- step-by-step instructions;
- technique cues;
- primary and secondary muscles;
- required equipment.

## Typography

Long dash characters were replaced with ordinary hyphens in the updated project content.
