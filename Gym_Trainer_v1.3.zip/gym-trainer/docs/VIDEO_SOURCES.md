# Video Sources

Gym Trainer does not download or redistribute exercise tutorial videos.

The application embeds YouTube videos using YouTube's privacy-enhanced player domain. A small set of high-frequency exercises uses locally curated YouTube IDs. The rest of the exercise library is resolved at runtime from public exercise indexes that contain YouTube references:

- exercemus/exercises: https://github.com/exercemus/exercises
- rthepen/workout-database: https://github.com/rthepen/workout-database

The resolver compares the Gym Trainer exercise name, aliases, required equipment, and primary muscles with available video records. Exact matches are preferred. Close variations are explicitly labeled in the interface.

If either external index or YouTube is unavailable, the written exercise instructions remain available and the interface offers a direct YouTube search backup.

No YouTube Data API key is required.
