import "dotenv/config";
import { PrismaPg } from "@prisma/adapter-pg";
import { PrismaClient } from "../generated/prisma/client";
import { EXERCISES } from "../src/data/exercises";
import { EQUIPMENT } from "../src/data/equipment";
import { MUSCLES } from "../src/data/muscles";

const connectionString = process.env.DATABASE_URL;
if (!connectionString) throw new Error("DATABASE_URL is required for seeding.");

const prisma = new PrismaClient({ adapter: new PrismaPg({ connectionString }) });

async function main() {
  for (const muscle of MUSCLES) {
    await prisma.muscle.upsert({
      where: { code: muscle.code },
      update: { displayName: muscle.displayName },
      create: { id: muscle.code, code: muscle.code, displayName: muscle.displayName }
    });
  }

  for (const item of EQUIPMENT) {
    await prisma.equipment.upsert({
      where: { code: item.code },
      update: { displayName: item.displayName },
      create: { id: item.code, code: item.code, displayName: item.displayName }
    });
  }

  for (const exercise of EXERCISES) {
    await prisma.exercise.upsert({
      where: { id: exercise.id },
      update: {
        slug: exercise.slug,
        name: exercise.name,
        description: exercise.description,
        instructions: exercise.instructions,
        tips: exercise.tips,
        movementPattern: exercise.movementPattern,
        difficulty: exercise.difficulty,
        compound: exercise.compound,
        unilateral: exercise.unilateral,
        active: exercise.active,
        minSets: exercise.defaultMinSets,
        maxSets: exercise.defaultMaxSets,
        minReps: exercise.defaultMinReps,
        maxReps: exercise.defaultMaxReps,
        restSeconds: exercise.defaultRestSeconds
      },
      create: {
        id: exercise.id,
        slug: exercise.slug,
        name: exercise.name,
        description: exercise.description,
        instructions: exercise.instructions,
        tips: exercise.tips,
        movementPattern: exercise.movementPattern,
        difficulty: exercise.difficulty,
        compound: exercise.compound,
        unilateral: exercise.unilateral,
        active: exercise.active,
        minSets: exercise.defaultMinSets,
        maxSets: exercise.defaultMaxSets,
        minReps: exercise.defaultMinReps,
        maxReps: exercise.defaultMaxReps,
        restSeconds: exercise.defaultRestSeconds
      }
    });

    await prisma.exerciseMuscle.deleteMany({ where: { exerciseId: exercise.id } });
    await prisma.exerciseEquipment.deleteMany({ where: { exerciseId: exercise.id } });
    await prisma.exerciseGoal.deleteMany({ where: { exerciseId: exercise.id } });
    await prisma.exerciseLocation.deleteMany({ where: { exerciseId: exercise.id } });

    await prisma.exerciseMuscle.createMany({
      data: [
        ...exercise.primaryMuscles.map((muscleId) => ({ exerciseId: exercise.id, muscleId, role: "PRIMARY" as const, contributionWeight: 1 })),
        ...exercise.secondaryMuscles.map((muscleId) => ({ exerciseId: exercise.id, muscleId, role: "SECONDARY" as const, contributionWeight: 0.35 }))
      ]
    });

    await prisma.exerciseEquipment.createMany({
      data: exercise.requiredEquipment.map((equipmentId) => ({ exerciseId: exercise.id, equipmentId, requirementType: "REQUIRED" as const }))
    });

    await prisma.exerciseGoal.createMany({
      data: exercise.compatibleGoals.map((goal) => ({ exerciseId: exercise.id, goal }))
    });

    await prisma.exerciseLocation.createMany({
      data: exercise.compatibleLocations.map((location) => ({ exerciseId: exercise.id, location }))
    });
  }

  await prisma.user.upsert({
    where: { email: "demo@gymtrainer.local" },
    update: {},
    create: { email: "demo@gymtrainer.local", name: "Demo User" }
  });

  process.stdout.write(`Seeded ${MUSCLES.length} muscles, ${EQUIPMENT.length} equipment items, and ${EXERCISES.length} exercises.\n`);
}

main()
  .finally(async () => {
    await prisma.$disconnect();
  });
