import { NextResponse } from "next/server";
import { EXERCISES } from "@/data/exercises";
import { EXERCISE_VIDEOS } from "@/data/exercise-videos";
import { resolveExternalExerciseVideo } from "@/lib/exercise-video-resolver";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const exerciseId = searchParams.get("exerciseId") ?? "";
  const exercise = EXERCISES.find((item) => item.id === exerciseId);

  if (!exercise) return NextResponse.json({ error: "Exercise not found" }, { status: 404 });

  const curated = EXERCISE_VIDEOS[exercise.id];
  if (curated) {
    return NextResponse.json({
      video: {
        ...curated,
        matchType: "curated"
      }
    });
  }

  const video = await resolveExternalExerciseVideo(exercise);
  return NextResponse.json({ video });
}
