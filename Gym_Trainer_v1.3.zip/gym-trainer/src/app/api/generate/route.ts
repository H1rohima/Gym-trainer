import { ZodError } from "zod";
import { generateWorkoutPlan } from "@/lib/workout-generator/generator";
import { parseUserProfile } from "@/lib/validation/profile";

export async function POST(request: Request) {
  try {
    const input = await request.json();
    const profile = parseUserProfile(input);
    const plan = generateWorkoutPlan(profile);
    return Response.json(plan);
  } catch (error) {
    if (error instanceof ZodError) {
      return Response.json({ error: "Invalid training preferences.", issues: error.issues.map((issue) => issue.message) }, { status: 400 });
    }
    return Response.json({ error: error instanceof Error ? error.message : "We couldn't build a valid program with these settings." }, { status: 422 });
  }
}
