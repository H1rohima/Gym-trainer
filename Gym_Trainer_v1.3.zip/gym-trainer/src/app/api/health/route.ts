import { NextResponse } from "next/server";
import { EXERCISE_COUNT } from "@/data/exercises";

export function GET() {
  return NextResponse.json({ status: "ok", application: "Gym Trainer", exerciseCount: EXERCISE_COUNT, generator: "deterministic-rule-based" });
}
