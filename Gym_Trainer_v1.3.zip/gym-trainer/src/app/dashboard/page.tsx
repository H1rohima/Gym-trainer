import { NavShell } from "@/components/NavShell";
import { DashboardView } from "@/components/program/DashboardView";

export default function DashboardPage() {
  return <NavShell><div className="page"><DashboardView /></div></NavShell>;
}
