import { NavShell } from "@/components/NavShell";
import { ExerciseLibrary } from "@/components/exercises/ExerciseLibrary";

export default function ExercisesPage() {
  return <NavShell><div className="page"><ExerciseLibrary /></div></NavShell>;
}
