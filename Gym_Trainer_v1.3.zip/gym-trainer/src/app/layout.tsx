import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Gym Trainer",
  description: "Build a workout that fits your goal, equipment, schedule, and priorities.",
  icons: { icon: "/gym-trainer-mark.png" }
};

const themeScript = `try{const t=JSON.parse(localStorage.getItem('gym-trainer-theme')||'"system"');if(t==='light'||t==='dark')document.documentElement.dataset.theme=t;else delete document.documentElement.dataset.theme}catch{}`;

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head><script dangerouslySetInnerHTML={{ __html: themeScript }} /></head>
      <body>{children}</body>
    </html>
  );
}
