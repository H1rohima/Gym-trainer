import Link from "next/link";
import { BrandLogo } from "@/components/BrandLogo";

export default function LandingPage() {
  return (
    <main>
      <section className="page" style={{ minHeight: "100vh", display: "grid", alignItems: "center" }}>
        <div style={{ maxWidth: 900 }}>
          <BrandLogo href="/" />
          <div className="eyebrow" style={{ marginTop: 34 }}>Personal workout planning</div>
          <h1 className="h1" style={{ margin: "16px 0 22px" }}>Your training. Your equipment. Your plan.</h1>
          <p className="muted" style={{ maxWidth: 650, fontSize: 19, lineHeight: 1.65, marginBottom: 30 }}>
            Build a practical weekly workout from your goal, experience, available equipment, muscle priorities, schedule, and session length.
          </p>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 10 }}>
            <Link className="btn btn-primary" href="/onboarding">Build My Program</Link>
            <Link className="btn btn-secondary" href="/exercises">Browse Exercises</Link>
          </div>
          <div className="grid-3" style={{ marginTop: 56 }}>
            <div className="card-flat" style={{ padding: 20 }}><div className="h3">Equipment-aware</div><p className="muted">Exercises are filtered by the equipment you actually have.</p></div>
            <div className="card-flat" style={{ padding: 20 }}><div className="h3">Deterministic</div><p className="muted">The same inputs produce the same plan through transparent rules.</p></div>
            <div className="card-flat" style={{ padding: 20 }}><div className="h3">Guided technique</div><p className="muted">Open animated movement previews with step-by-step instructions and technique cues.</p></div>
          </div>
        </div>
      </section>
    </main>
  );
}
