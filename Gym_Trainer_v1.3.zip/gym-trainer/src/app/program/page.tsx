import { NavShell } from "@/components/NavShell";
import { ProgramView } from "@/components/program/ProgramView";

export default function ProgramPage() {
  return <NavShell><div className="page"><ProgramView /></div></NavShell>;
}
