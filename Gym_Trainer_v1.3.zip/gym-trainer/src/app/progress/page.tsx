import { NavShell } from "@/components/NavShell";
import { ProgressView } from "@/components/progress/ProgressView";

export default function ProgressPage() {
  return <NavShell><div className="page"><ProgressView /></div></NavShell>;
}
