import { NavShell } from "@/components/NavShell";
import { SettingsView } from "@/components/settings/SettingsView";

export default function SettingsPage() {
  return <NavShell><div className="page"><SettingsView /></div></NavShell>;
}
