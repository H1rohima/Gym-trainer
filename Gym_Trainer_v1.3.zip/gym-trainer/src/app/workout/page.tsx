import { NavShell } from "@/components/NavShell";
import { WorkoutSession } from "@/components/workout/WorkoutSession";

export default function WorkoutPage() {
  return <NavShell><div className="page"><WorkoutSession /></div></NavShell>;
}
