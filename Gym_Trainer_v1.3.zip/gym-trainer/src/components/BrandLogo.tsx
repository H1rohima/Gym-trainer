import Image from "next/image";
import Link from "next/link";

export function BrandLogo({ href = "/dashboard", compact = false }: { href?: string; compact?: boolean }) {
  return (
    <Link href={href} className={`brand-logo ${compact ? "brand-logo-compact" : ""}`} aria-label="Gym Trainer home">
      {compact ? (
        <Image src="/gym-trainer-mark.png" alt="Gym Trainer" width={284} height={213} className="brand-logo-mark" priority />
      ) : (
        <span className="brand-logo-wordmark" aria-hidden="true">
          <Image src="/gym-trainer-logo.png" alt="" width={1055} height={225} className="brand-logo-image brand-logo-image-light" priority />
          <Image src="/gym-trainer-logo-dark.png" alt="" width={1055} height={225} className="brand-logo-image brand-logo-image-dark" priority />
        </span>
      )}
    </Link>
  );
}
