"use client";

import Link from "next/link";
import { BrandLogo } from "@/components/BrandLogo";
import { usePathname } from "next/navigation";
import type { ReactNode } from "react";

const desktopLinks = [
  ["/dashboard", "Home"],
  ["/program", "My Program"],
  ["/workout", "Workouts"],
  ["/exercises", "Exercises"],
  ["/progress", "Progress"],
  ["/settings", "Settings"]
] as const;

const mobileLinks = [
  ["/dashboard", "Home"],
  ["/program", "Program"],
  ["/workout", "Workout"],
  ["/progress", "Progress"]
] as const;

function isActive(pathname: string, href: string) {
  if (href === "/workout") return pathname.startsWith("/workout");
  return pathname === href;
}

export function NavShell({ children }: { children: ReactNode }) {
  const pathname = usePathname();

  return (
    <div className="app-layout">
      <aside className="sidebar">
        <BrandLogo href="/dashboard" />
        <nav className="nav-list" aria-label="Main navigation">
          {desktopLinks.map(([href, label]) => <Link key={href} href={href} className="nav-link" data-active={isActive(pathname, href)}>{label}</Link>)}
        </nav>
      </aside>
      <main className="content">{children}</main>
      <nav className="mobile-nav" aria-label="Mobile navigation">
        {mobileLinks.map(([href, label]) => <Link key={href} href={href} className="nav-link" data-active={isActive(pathname, href)}>{label}</Link>)}
      </nav>
    </div>
  );
}
