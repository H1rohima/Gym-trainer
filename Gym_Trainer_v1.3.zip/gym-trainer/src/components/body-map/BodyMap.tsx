"use client";

import { useState, type ReactNode } from "react";
import { MUSCLE_GROUP_LABELS, type OnboardingMuscleGroup } from "@/data/onboarding";
import type { MusclePriority } from "@/types/domain";

interface BodyMapProps {
  selected: OnboardingMuscleGroup[];
  priorities?: Partial<Record<OnboardingMuscleGroup, MusclePriority>>;
  onToggle: (group: OnboardingMuscleGroup) => void;
}

interface RegionProps {
  group: OnboardingMuscleGroup;
  selected: boolean;
  priority: MusclePriority;
  onToggle: (group: OnboardingMuscleGroup) => void;
  children: ReactNode;
}

const priorityColor: Record<MusclePriority, string> = {
  LOW: "var(--muscle-low)",
  MEDIUM: "var(--muscle-medium)",
  HIGH: "var(--muscle-high)"
};

function Region({ group, selected, priority, onToggle, children }: RegionProps) {
  return (
    <g
      role="button"
      tabIndex={0}
      aria-label={`${MUSCLE_GROUP_LABELS[group]}${selected ? `, selected, ${priority.toLowerCase()} priority` : ""}`}
      onClick={() => onToggle(group)}
      onKeyDown={(event) => {
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          onToggle(group);
        }
      }}
      style={{
        cursor: "pointer",
        color: selected ? priorityColor[priority] : "var(--surface-2)",
        filter: selected && priority === "HIGH" ? "drop-shadow(0 2px 3px color-mix(in srgb, var(--muscle-high) 24%, transparent))" : "none"
      }}
    >
      {children}
    </g>
  );
}

function priorityFor(group: OnboardingMuscleGroup, priorities?: Partial<Record<OnboardingMuscleGroup, MusclePriority>>) {
  return priorities?.[group] ?? "MEDIUM";
}

function FrontBody({ selected, priorities, onToggle }: BodyMapProps) {
  const region = (group: OnboardingMuscleGroup, children: ReactNode) => (
    <Region group={group} selected={selected.includes(group)} priority={priorityFor(group, priorities)} onToggle={onToggle}>{children}</Region>
  );

  return (
    <svg viewBox="0 0 260 520" width="100%" role="img" aria-label="Front body muscle selector" style={{ maxHeight: 520 }}>
      <circle cx="130" cy="44" r="28" fill="var(--surface-2)" stroke="var(--border)" strokeWidth="2" />
      <path d="M94 78 Q130 66 166 78 L178 196 Q171 245 160 281 L100 281 Q89 245 82 196 Z" fill="var(--surface)" stroke="var(--border)" strokeWidth="2" />
      <path d="M99 281 L126 281 L119 470 Q104 488 91 470 Z" fill="var(--surface)" stroke="var(--border)" strokeWidth="2" />
      <path d="M134 281 L161 281 L169 470 Q156 488 141 470 Z" fill="var(--surface)" stroke="var(--border)" strokeWidth="2" />
      <path d="M82 98 L58 112 L40 246 Q48 256 59 249 L88 148 Z" fill="var(--surface)" stroke="var(--border)" strokeWidth="2" />
      <path d="M178 98 L202 112 L220 246 Q212 256 201 249 L172 148 Z" fill="var(--surface)" stroke="var(--border)" strokeWidth="2" />
      {region("CHEST", <path d="M99 105 Q113 91 129 104 L129 155 Q108 162 96 145 Z M131 104 Q147 91 161 105 L164 145 Q152 162 131 155 Z" fill="currentColor" stroke="var(--muscle-region-border)" />)}
      {region("SHOULDERS", <><ellipse cx="88" cy="111" rx="18" ry="25" fill="currentColor" stroke="var(--muscle-region-border)" /><ellipse cx="172" cy="111" rx="18" ry="25" fill="currentColor" stroke="var(--muscle-region-border)" /></>)}
      {region("BICEPS", <><ellipse cx="70" cy="169" rx="12" ry="30" fill="currentColor" stroke="var(--muscle-region-border)" /><ellipse cx="190" cy="169" rx="12" ry="30" fill="currentColor" stroke="var(--muscle-region-border)" /></>)}
      {region("FOREARMS", <><path d="M57 196 L45 244 Q51 251 58 245 L70 205 Z" fill="currentColor" stroke="var(--muscle-region-border)" /><path d="M203 196 L215 244 Q209 251 202 245 L190 205 Z" fill="currentColor" stroke="var(--muscle-region-border)" /></>)}
      {region("ABS", <path d="M113 160 L147 160 L153 244 L107 244 Z" fill="currentColor" stroke="var(--muscle-region-border)" />)}
      {region("OBLIQUES", <><path d="M96 157 L112 160 L106 244 L94 226 Z" fill="currentColor" stroke="var(--muscle-region-border)" /><path d="M164 157 L148 160 L154 244 L166 226 Z" fill="currentColor" stroke="var(--muscle-region-border)" /></>)}
      {region("QUADS", <><path d="M99 290 L124 290 L117 384 L95 380 Z" fill="currentColor" stroke="var(--muscle-region-border)" /><path d="M136 290 L161 290 L165 380 L143 384 Z" fill="currentColor" stroke="var(--muscle-region-border)" /></>)}
      {region("CALVES", <><path d="M94 392 L116 396 L111 466 L94 466 Z" fill="currentColor" stroke="var(--muscle-region-border)" /><path d="M144 396 L166 392 L166 466 L149 466 Z" fill="currentColor" stroke="var(--muscle-region-border)" /></>)}
    </svg>
  );
}

function BackBody({ selected, priorities, onToggle }: BodyMapProps) {
  const region = (group: OnboardingMuscleGroup, children: ReactNode) => (
    <Region group={group} selected={selected.includes(group)} priority={priorityFor(group, priorities)} onToggle={onToggle}>{children}</Region>
  );

  return (
    <svg viewBox="0 0 260 520" width="100%" role="img" aria-label="Back body muscle selector" style={{ maxHeight: 520 }}>
      <circle cx="130" cy="44" r="28" fill="var(--surface-2)" stroke="var(--border)" strokeWidth="2" />
      <path d="M94 78 Q130 66 166 78 L178 196 Q171 245 160 281 L100 281 Q89 245 82 196 Z" fill="var(--surface)" stroke="var(--border)" strokeWidth="2" />
      <path d="M99 281 L126 281 L119 470 Q104 488 91 470 Z" fill="var(--surface)" stroke="var(--border)" strokeWidth="2" />
      <path d="M134 281 L161 281 L169 470 Q156 488 141 470 Z" fill="var(--surface)" stroke="var(--border)" strokeWidth="2" />
      <path d="M82 98 L58 112 L40 246 Q48 256 59 249 L88 148 Z" fill="var(--surface)" stroke="var(--border)" strokeWidth="2" />
      <path d="M178 98 L202 112 L220 246 Q212 256 201 249 L172 148 Z" fill="var(--surface)" stroke="var(--border)" strokeWidth="2" />
      {region("SHOULDERS", <><ellipse cx="88" cy="111" rx="18" ry="25" fill="currentColor" stroke="var(--muscle-region-border)" /><ellipse cx="172" cy="111" rx="18" ry="25" fill="currentColor" stroke="var(--muscle-region-border)" /></>)}
      {region("TRICEPS", <><ellipse cx="70" cy="169" rx="12" ry="30" fill="currentColor" stroke="var(--muscle-region-border)" /><ellipse cx="190" cy="169" rx="12" ry="30" fill="currentColor" stroke="var(--muscle-region-border)" /></>)}
      {region("FOREARMS", <><path d="M57 196 L45 244 Q51 251 58 245 L70 205 Z" fill="currentColor" stroke="var(--muscle-region-border)" /><path d="M203 196 L215 244 Q209 251 202 245 L190 205 Z" fill="currentColor" stroke="var(--muscle-region-border)" /></>)}
      {region("UPPER_BACK", <path d="M102 96 L158 96 L155 158 L105 158 Z" fill="currentColor" stroke="var(--muscle-region-border)" />)}
      {region("LATS", <><path d="M94 142 L112 153 L107 220 L91 205 Z" fill="currentColor" stroke="var(--muscle-region-border)" /><path d="M166 142 L148 153 L153 220 L169 205 Z" fill="currentColor" stroke="var(--muscle-region-border)" /></>)}
      {region("LOWER_BACK", <path d="M108 196 L152 196 L158 249 L102 249 Z" fill="currentColor" stroke="var(--muscle-region-border)" />)}
      {region("GLUTES", <path d="M100 252 Q115 240 129 254 L127 294 Q111 302 98 286 Z M131 254 Q145 240 160 252 L162 286 Q149 302 133 294 Z" fill="currentColor" stroke="var(--muscle-region-border)" />)}
      {region("HAMSTRINGS", <><path d="M99 300 L124 300 L117 386 L95 382 Z" fill="currentColor" stroke="var(--muscle-region-border)" /><path d="M136 300 L161 300 L165 382 L143 386 Z" fill="currentColor" stroke="var(--muscle-region-border)" /></>)}
      {region("CALVES", <><path d="M94 392 L116 396 L111 466 L94 466 Z" fill="currentColor" stroke="var(--muscle-region-border)" /><path d="M144 396 L166 392 L166 466 L149 466 Z" fill="currentColor" stroke="var(--muscle-region-border)" /></>)}
    </svg>
  );
}

export function BodyMap(props: BodyMapProps) {
  const [view, setView] = useState<"front" | "back">("front");

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "center", gap: 8, marginBottom: 12 }}>
        <button className={`pill ${view === "front" ? "pill-selected" : ""}`} onClick={() => setView("front")}>Front</button>
        <button className={`pill ${view === "back" ? "pill-selected" : ""}`} onClick={() => setView("back")}>Back</button>
      </div>
      <div style={{ width: "min(100%, 330px)", margin: "0 auto" }}>{view === "front" ? <FrontBody {...props} /> : <BackBody {...props} />}</div>
      <div className="muscle-priority-legend" aria-label="Muscle priority color scale">
        <span><i className="muscle-swatch muscle-swatch-low" />Low</span>
        <span><i className="muscle-swatch muscle-swatch-medium" />Medium</span>
        <span><i className="muscle-swatch muscle-swatch-high" />High</span>
      </div>
    </div>
  );
}
