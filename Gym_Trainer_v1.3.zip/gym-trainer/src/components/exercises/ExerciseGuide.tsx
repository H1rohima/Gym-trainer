import { EXERCISES } from "@/data/exercises";
import { ExerciseVideo } from "@/components/exercises/ExerciseVideo";
import { buildExerciseOverview } from "@/lib/exercise-guidance";

function pretty(value: string) {
  return value.toLowerCase().replaceAll("_", " ").replace(/\b\w/g, (letter) => letter.toUpperCase());
}

export function ExerciseGuide({ exerciseId, compact = false }: { exerciseId: string; compact?: boolean }) {
  const exercise = EXERCISES.find((item) => item.id === exerciseId);
  if (!exercise) return null;

  return (
    <div className="exercise-guide">
      <ExerciseVideo exerciseId={exercise.id} exerciseName={exercise.name} />
      <div className="exercise-guide-copy">
        <div>
          <div className="eyebrow">About this exercise</div>
          <p className="muted" style={{ lineHeight: 1.6, marginBottom: 0 }}>{buildExerciseOverview(exercise)}</p>
        </div>
        <div>
          <div className="h3">How to perform it</div>
          <ol className="instruction-list">
            {exercise.instructions.map((item, index) => <li key={`${exercise.id}-step-${index}`}>{item}</li>)}
          </ol>
        </div>
        {compact ? null : (
          <div>
            <div className="h3">Technique cues</div>
            <ul className="tip-list">
              {exercise.tips.map((item, index) => <li key={`${exercise.id}-tip-${index}`}>{item}</li>)}
            </ul>
          </div>
        )}
        <div className="exercise-guide-meta">
          <span className="pill">Primary: {exercise.primaryMuscles.map(pretty).join(", ")}</span>
          {exercise.secondaryMuscles.length ? <span className="pill">Secondary: {exercise.secondaryMuscles.map(pretty).join(", ")}</span> : null}
          <span className="pill">Equipment: {exercise.requiredEquipment.map(pretty).join(", ")}</span>
        </div>
      </div>
    </div>
  );
}
