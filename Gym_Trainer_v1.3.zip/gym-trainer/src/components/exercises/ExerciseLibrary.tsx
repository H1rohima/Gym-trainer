"use client";

import { useMemo, useState } from "react";
import { ExerciseGuide } from "@/components/exercises/ExerciseGuide";
import { EXERCISES } from "@/data/exercises";
import { EQUIPMENT } from "@/data/equipment";
import { MUSCLES } from "@/data/muscles";
import { buildExerciseOverview } from "@/lib/exercise-guidance";
import type { Difficulty, EquipmentCode, Exercise, MuscleCode } from "@/types/domain";

function pretty(value: string) {
  return value.toLowerCase().replaceAll("_", " ").replace(/\b\w/g, (letter) => letter.toUpperCase());
}

function ExerciseDetail({ exercise, onClose }: { exercise: Exercise; onClose: () => void }) {
  return (
    <div className="card" style={{ padding: 24, position: "sticky", top: 18 }}>
      <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "start" }}>
        <div>
          <div className="eyebrow">Exercise details</div>
          <h2 className="h2" style={{ margin: "7px 0" }}>{exercise.name}</h2>
          <div className="muted">{pretty(exercise.movementPattern)} - {pretty(exercise.difficulty)}</div>
        </div>
        <button className="btn btn-ghost" onClick={onClose}>Close</button>
      </div>
      <div className="grid-2" style={{ margin: "18px 0" }}>
        <div><div className="muted">Primary</div><strong>{exercise.primaryMuscles.map(pretty).join(", ")}</strong></div>
        <div><div className="muted">Secondary</div><strong>{exercise.secondaryMuscles.map(pretty).join(", ") || "-"}</strong></div>
        <div><div className="muted">Equipment</div><strong>{exercise.requiredEquipment.map(pretty).join(", ")}</strong></div>
        <div><div className="muted">Rest</div><strong>{exercise.defaultRestSeconds} sec</strong></div>
        <div><div className="muted">Suggested sets</div><strong>{exercise.defaultMinSets}-{exercise.defaultMaxSets}</strong></div>
        <div><div className="muted">Suggested reps</div><strong>{exercise.defaultMinReps}-{exercise.defaultMaxReps}</strong></div>
      </div>
      <ExerciseGuide exerciseId={exercise.id} />
    </div>
  );
}

export function ExerciseLibrary() {
  const [query, setQuery] = useState("");
  const [muscle, setMuscle] = useState<MuscleCode | "ALL">("ALL");
  const [equipment, setEquipment] = useState<EquipmentCode | "ALL">("ALL");
  const [difficulty, setDifficulty] = useState<Difficulty | "ALL">("ALL");
  const [selected, setSelected] = useState<Exercise | null>(null);

  const filtered = useMemo(() => EXERCISES.filter((exercise) => {
    const textMatch = exercise.name.toLowerCase().includes(query.toLowerCase());
    const muscleMatch = muscle === "ALL" || exercise.primaryMuscles.includes(muscle) || exercise.secondaryMuscles.includes(muscle);
    const equipmentMatch = equipment === "ALL" || exercise.requiredEquipment.includes(equipment);
    const difficultyMatch = difficulty === "ALL" || exercise.difficulty === difficulty;
    return textMatch && muscleMatch && equipmentMatch && difficultyMatch;
  }), [query, muscle, equipment, difficulty]);

  return (
    <div>
      <div className="section-title">
        <div>
          <div className="eyebrow">Exercise library</div>
          <h1 className="h2" style={{ margin: "7px 0" }}>Browse {EXERCISES.length} curated exercises</h1>
          <div className="muted">Open any exercise to see a video demonstration, step-by-step instructions, technique cues, muscles, equipment, sets, reps, and rest.</div>
        </div>
      </div>
      <div className="card-flat" style={{ padding: 14, marginBottom: 18 }}>
        <div className="grid-2">
          <input className="input" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search exercises" aria-label="Search exercises" />
          <div className="filter-grid">
            <select className="input" value={muscle} onChange={(event) => setMuscle(event.target.value as MuscleCode | "ALL")} aria-label="Filter by muscle"><option value="ALL">All muscles</option>{MUSCLES.map((item) => <option key={item.code} value={item.code}>{item.displayName}</option>)}</select>
            <select className="input" value={equipment} onChange={(event) => setEquipment(event.target.value as EquipmentCode | "ALL")} aria-label="Filter by equipment"><option value="ALL">All equipment</option>{EQUIPMENT.map((item) => <option key={item.code} value={item.code}>{item.displayName}</option>)}</select>
            <select className="input" value={difficulty} onChange={(event) => setDifficulty(event.target.value as Difficulty | "ALL")} aria-label="Filter by difficulty"><option value="ALL">All levels</option><option value="BEGINNER">Beginner</option><option value="INTERMEDIATE">Intermediate</option><option value="ADVANCED">Advanced</option></select>
          </div>
        </div>
      </div>
      <div className={`exercise-layout ${selected ? "exercise-layout-with-detail" : ""}`}>
        <div className="stack">
          <div className="muted">{filtered.length} exercises</div>
          {filtered.map((exercise) => (
            <button key={exercise.id} className="card-flat exercise-list-card" style={{ padding: 17, textAlign: "left", color: "var(--text)" }} onClick={() => setSelected(exercise)}>
              <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "start" }}>
                <div>
                  <div className="h3">{exercise.name}</div>
                  <div className="muted" style={{ marginTop: 5 }}>{buildExerciseOverview(exercise)}</div>
                  <div className="muted" style={{ marginTop: 7, fontSize: 13 }}>{exercise.primaryMuscles.map(pretty).join(", ")} - {exercise.requiredEquipment.map(pretty).join(", ")}</div>
                </div>
                <span className="pill">{pretty(exercise.difficulty)}</span>
              </div>
            </button>
          ))}
          {filtered.length === 0 ? <div className="card-flat" style={{ padding: 24 }}>No exercises match these filters.</div> : null}
        </div>
        {selected ? <ExerciseDetail exercise={selected} onClose={() => setSelected(null)} /> : null}
      </div>
    </div>
  );
}
