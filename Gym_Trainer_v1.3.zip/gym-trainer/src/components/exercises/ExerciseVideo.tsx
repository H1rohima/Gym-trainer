"use client";

import { useEffect, useMemo, useState } from "react";

interface VideoResponse {
  youtubeId: string;
  title: string;
  channel: string;
  startSeconds?: number;
  matchType: "curated" | "exact" | "close";
}

export function ExerciseVideo({ exerciseId, exerciseName }: { exerciseId: string; exerciseName: string }) {
  const [video, setVideo] = useState<VideoResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [failed, setFailed] = useState(false);
  const searchUrl = useMemo(() => `https://www.youtube.com/results?search_query=${encodeURIComponent(`${exerciseName} exercise tutorial proper form`)}`, [exerciseName]);

  useEffect(() => {
    const controller = new AbortController();
    setLoading(true);
    setFailed(false);

    fetch(`/api/exercise-video?exerciseId=${encodeURIComponent(exerciseId)}`, { signal: controller.signal })
      .then((response) => response.ok ? response.json() : Promise.reject(new Error("Video lookup failed")))
      .then((data: { video: VideoResponse | null }) => {
        setVideo(data.video);
        setFailed(!data.video);
      })
      .catch((error: unknown) => {
        if (error instanceof DOMException && error.name === "AbortError") return;
        setFailed(true);
      })
      .finally(() => setLoading(false));

    return () => controller.abort();
  }, [exerciseId]);

  if (loading) {
    return (
      <div className="exercise-video-loading" aria-live="polite">
        <div className="exercise-video-loading-frame" />
        <div>
          <div className="eyebrow">Video demonstration</div>
          <div className="h3" style={{ marginTop: 6 }}>Loading technique video...</div>
        </div>
      </div>
    );
  }

  if (!video || failed) {
    return (
      <div className="exercise-video-fallback">
        <div>
          <div className="eyebrow">Video demonstration</div>
          <div className="h3" style={{ marginTop: 6 }}>Open the {exerciseName} demonstration</div>
          <p className="muted" style={{ margin: "7px 0 0", lineHeight: 1.55 }}>The embedded source is temporarily unavailable. YouTube search is kept as a backup.</p>
        </div>
        <a className="btn btn-secondary" href={searchUrl} target="_blank" rel="noreferrer">Open on YouTube</a>
      </div>
    );
  }

  const watchUrl = `https://www.youtube.com/watch?v=${video.youtubeId}${video.startSeconds ? `&t=${video.startSeconds}s` : ""}`;
  const embedUrl = `https://www.youtube-nocookie.com/embed/${video.youtubeId}?rel=0${video.startSeconds ? `&start=${video.startSeconds}` : ""}`;
  const isCloseMatch = video.matchType === "close";

  return (
    <div className="exercise-video">
      <div className="exercise-video-frame">
        <iframe
          src={embedUrl}
          title={`${exerciseName} technique video`}
          loading="lazy"
          referrerPolicy="strict-origin-when-cross-origin"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
          allowFullScreen
        />
      </div>
      <div className="exercise-video-copy">
        <div>
          <div className="eyebrow">{isCloseMatch ? "Related technique demonstration" : "Video demonstration"}</div>
          <div className="h3" style={{ marginTop: 6 }}>{video.title}</div>
          <p className="muted" style={{ margin: "7px 0 0" }}>YouTube{video.channel !== "YouTube" ? ` - ${video.channel}` : ""}</p>
          {isCloseMatch ? <p className="muted" style={{ margin: "5px 0 0", fontSize: 13 }}>Closest available movement reference. Follow the written instructions for this exact variation.</p> : null}
        </div>
        <a className="btn btn-secondary" href={watchUrl} target="_blank" rel="noreferrer">Open on YouTube</a>
      </div>
    </div>
  );
}
