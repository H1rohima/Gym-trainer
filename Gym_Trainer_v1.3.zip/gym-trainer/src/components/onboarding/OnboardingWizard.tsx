"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { BodyMap } from "@/components/body-map/BodyMap";
import { BrandLogo } from "@/components/BrandLogo";
import { Button } from "@/components/ui/Button";
import { BASIC_GYM_EQUIPMENT, FULL_GYM_EQUIPMENT, HOME_EQUIPMENT } from "@/data/equipment";
import { GROUP_TO_MUSCLES, MUSCLE_GROUP_LABELS, type OnboardingMuscleGroup } from "@/data/onboarding";
import { storage } from "@/lib/storage";
import type { EquipmentCode, Experience, Goal, MusclePriority, SessionDuration, TrainingLocation, UserProfile, WorkoutPlan } from "@/types/domain";

const goalOptions: Array<{ value: Goal; title: string; description: string }> = [
  { value: "HYPERTROPHY", title: "Muscle Growth", description: "Build muscle with balanced resistance training." },
  { value: "STRENGTH", title: "Strength", description: "Focus on heavier compound movements and strength progression." },
  { value: "GENERAL_FITNESS", title: "General Fitness", description: "Build a balanced routine for strength, movement, and consistency." }
];

const experienceOptions: Array<{ value: Experience; title: string; description: string }> = [
  { value: "BEGINNER", title: "Beginner", description: "New to structured resistance training." },
  { value: "INTERMEDIATE", title: "Intermediate", description: "Comfortable with common exercises and consistent training." },
  { value: "ADVANCED", title: "Advanced", description: "Experienced with structured resistance training." }
];

const durationOptions: Array<{ value: SessionDuration; title: string }> = [
  { value: "SHORT", title: "20-30 min" },
  { value: "MEDIUM", title: "30-45 min" },
  { value: "STANDARD", title: "45-60 min" },
  { value: "LONG", title: "60+ min" }
];

const durationLabels: Record<SessionDuration, string> = {
  SHORT: "20-30 min",
  MEDIUM: "30-45 min",
  STANDARD: "45-60 min",
  LONG: "60+ min"
};

const equipmentLabels: Record<EquipmentCode, string> = {
  BODYWEIGHT: "Bodyweight",
  PULL_UP_BAR: "Pull-Up Bar",
  DUMBBELL: "Dumbbells",
  KETTLEBELL: "Kettlebell",
  BARBELL: "Barbell",
  BENCH: "Bench",
  CABLE: "Cable",
  MACHINE: "Machine",
  BANDS: "Resistance Bands",
  OTHER: "Other"
};

function SelectCard({ selected, title, description, onClick }: { selected: boolean; title: string; description?: string; onClick: () => void }) {
  return (
    <button type="button" className="option-card" data-selected={selected} onClick={onClick}>
      <div className="h3">{title}</div>
      {description ? <div className="muted" style={{ marginTop: 7, lineHeight: 1.45 }}>{description}</div> : null}
    </button>
  );
}

export function OnboardingWizard() {
  const router = useRouter();
  const [step, setStep] = useState(0);
  const [goal, setGoal] = useState<Goal>("HYPERTROPHY");
  const [location, setLocation] = useState<TrainingLocation>("HOME");
  const [homeEquipment, setHomeEquipment] = useState<EquipmentCode[]>([]);
  const [noEquipment, setNoEquipment] = useState(true);
  const [gymPreset, setGymPreset] = useState<"BASIC" | "FULL">("FULL");
  const [experience, setExperience] = useState<Experience>("BEGINNER");
  const [selectedGroups, setSelectedGroups] = useState<OnboardingMuscleGroup[]>([]);
  const [groupPriorities, setGroupPriorities] = useState<Partial<Record<OnboardingMuscleGroup, MusclePriority>>>({});
  const [daysPerWeek, setDaysPerWeek] = useState<1 | 2 | 3 | 4 | 5 | 6 | 7>(3);
  const [sessionDuration, setSessionDuration] = useState<SessionDuration>("STANDARD");
  const [error, setError] = useState<string | null>(null);
  const [building, setBuilding] = useState(false);

  const totalSteps = 8;
  const actualEquipment = useMemo(() => {
    if (location === "HOME") return noEquipment ? [] : homeEquipment;
    return gymPreset === "FULL" ? FULL_GYM_EQUIPMENT : BASIC_GYM_EQUIPMENT;
  }, [location, noEquipment, homeEquipment, gymPreset]);

  function toggleHomeEquipment(item: EquipmentCode) {
    setNoEquipment(false);
    setHomeEquipment((current) => current.includes(item) ? current.filter((value) => value !== item) : [...current, item]);
  }

  function toggleMuscle(group: OnboardingMuscleGroup) {
    setSelectedGroups((current) => {
      if (current.includes(group)) return current.filter((item) => item !== group);
      if (!groupPriorities[group]) setGroupPriorities((values) => ({ ...values, [group]: "MEDIUM" }));
      return [...current, group];
    });
  }

  function buildProfile(): UserProfile {
    const musclePriorities: UserProfile["musclePriorities"] = {};
    for (const group of selectedGroups) {
      const priority = groupPriorities[group] ?? "MEDIUM";
      for (const muscle of GROUP_TO_MUSCLES[group]) musclePriorities[muscle] = priority;
    }

    return {
      goal,
      experience,
      location,
      equipment: actualEquipment.filter((item) => item !== "BODYWEIGHT"),
      daysPerWeek,
      sessionDuration,
      musclePriorities
    };
  }

  async function buildProgram() {
    setError(null);
    setBuilding(true);
    try {
      const profile = buildProfile();
      const response = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(profile)
      });
      const result = await response.json() as WorkoutPlan & { error?: string };
      if (!response.ok) throw new Error(result.error ?? "We couldn't build a valid program with these settings.");
      storage.setProfile(profile);
      storage.setPlan(result);
      router.push("/program");
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "We couldn't build a valid program with these settings.");
    } finally {
      setBuilding(false);
    }
  }

  const stepContent = [
    <div key="goal">
      <div className="eyebrow">Goal</div>
      <h1 className="h2" style={{ margin: "10px 0 24px" }}>What is your main goal?</h1>
      <div className="option-grid">
        {goalOptions.map((option) => <SelectCard key={option.value} selected={goal === option.value} title={option.title} description={option.description} onClick={() => setGoal(option.value)} />)}
      </div>
    </div>,
    <div key="location">
      <div className="eyebrow">Training location</div>
      <h1 className="h2" style={{ margin: "10px 0 24px" }}>Where do you train?</h1>
      <div className="option-grid">
        <SelectCard selected={location === "HOME"} title="Home" description="Train with the equipment you have." onClick={() => setLocation("HOME")} />
        <SelectCard selected={location === "GYM"} title="Gym" description="Use gym machines, cables, free weights, and other available equipment." onClick={() => setLocation("GYM")} />
      </div>
    </div>,
    <div key="equipment">
      <div className="eyebrow">Equipment</div>
      <h1 className="h2" style={{ margin: "10px 0 10px" }}>{location === "HOME" ? "What equipment do you have?" : "What kind of gym do you use?"}</h1>
      <p className="muted" style={{ marginBottom: 24 }}>Your plan will never require equipment outside this selection.</p>
      {location === "HOME" ? (
        <div className="option-grid">
          <SelectCard selected={noEquipment} title="No Equipment" description="Bodyweight exercises only." onClick={() => { setNoEquipment(true); setHomeEquipment([]); }} />
          {HOME_EQUIPMENT.map((item) => <SelectCard key={item} selected={!noEquipment && homeEquipment.includes(item)} title={equipmentLabels[item]} onClick={() => toggleHomeEquipment(item)} />)}
        </div>
      ) : (
        <div className="option-grid">
          <SelectCard selected={gymPreset === "BASIC"} title="Basic Gym" description="Bodyweight, pull-up bar, dumbbells, barbell, bench, and cable." onClick={() => setGymPreset("BASIC")} />
          <SelectCard selected={gymPreset === "FULL"} title="Full Gym" description="Free weights, cables, machines, kettlebells, benches, and pull-up stations." onClick={() => setGymPreset("FULL")} />
        </div>
      )}
    </div>,
    <div key="experience">
      <div className="eyebrow">Experience</div>
      <h1 className="h2" style={{ margin: "10px 0 24px" }}>What is your training experience?</h1>
      <div className="option-grid">
        {experienceOptions.map((option) => <SelectCard key={option.value} selected={experience === option.value} title={option.title} description={option.description} onClick={() => setExperience(option.value)} />)}
      </div>
    </div>,
    <div key="muscles">
      <div className="eyebrow">Focus</div>
      <h1 className="h2" style={{ margin: "10px 0 8px" }}>What do you want to focus on?</h1>
      <p className="muted" style={{ marginBottom: 20 }}>Select any muscles you want to prioritize. Leave everything unselected for a balanced plan.</p>
      <div className="grid-2" style={{ alignItems: "start" }}>
        <div className="card-flat" style={{ padding: 16 }}><BodyMap selected={selectedGroups} priorities={groupPriorities} onToggle={toggleMuscle} /></div>
        <div className="stack">
          {selectedGroups.length === 0 ? <div className="card-flat" style={{ padding: 22 }}><div className="h3">Balanced plan</div><p className="muted">No muscles selected. The generator will distribute attention across the full body.</p></div> : null}
          {selectedGroups.map((group) => (
            <div key={group} className="card-flat" style={{ padding: 16 }}>
              <div style={{ display: "flex", justifyContent: "space-between", gap: 10, alignItems: "center", marginBottom: 12 }}>
                <strong>{MUSCLE_GROUP_LABELS[group]}</strong>
                <button className="btn btn-ghost" style={{ minHeight: 32, padding: "0 8px" }} onClick={() => toggleMuscle(group)}>Remove</button>
              </div>
              <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                {(["LOW", "MEDIUM", "HIGH"] as MusclePriority[]).map((priority) => <button key={priority} className={`pill ${(groupPriorities[group] ?? "MEDIUM") === priority ? "pill-selected" : ""}`} onClick={() => setGroupPriorities((current) => ({ ...current, [group]: priority }))}>{priority[0] + priority.slice(1).toLowerCase()}</button>)}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>,
    <div key="frequency">
      <div className="eyebrow">Frequency</div>
      <h1 className="h2" style={{ margin: "10px 0 24px" }}>How many days can you train?</h1>
      <div className="option-grid">
        {([1, 2, 3, 4, 5, 6, 7] as const).map((days) => <SelectCard key={days} selected={daysPerWeek === days} title={`${days} ${days === 1 ? "day" : "days"}`} description={days <= 2 ? "Lower frequency with more full-body work per session." : days >= 6 ? "Higher frequency with shorter, more focused sessions." : "Balanced weekly training frequency."} onClick={() => setDaysPerWeek(days)} />)}
      </div>
      {daysPerWeek >= 6 ? <p className="muted" style={{ marginTop: 16, lineHeight: 1.55 }}>High-frequency plans use fewer exercises per session to keep the weekly program practical. Recovery still matters, so adjust your schedule when needed.</p> : null}
    </div>,
    <div key="duration">
      <div className="eyebrow">Session length</div>
      <h1 className="h2" style={{ margin: "10px 0 24px" }}>How long can you train?</h1>
      <div className="option-grid">
        {durationOptions.map((option) => <SelectCard key={option.value} selected={sessionDuration === option.value} title={option.title} onClick={() => setSessionDuration(option.value)} />)}
      </div>
    </div>,
    <div key="review">
      <div className="eyebrow">Review</div>
      <h1 className="h2" style={{ margin: "10px 0 24px" }}>Ready to build your program?</h1>
      <div className="card-flat" style={{ padding: 22 }}>
        <div className="grid-2">
          <div><div className="muted">Goal</div><strong>{goalOptions.find((item) => item.value === goal)?.title}</strong></div>
          <div><div className="muted">Location</div><strong>{location === "HOME" ? "Home" : "Gym"}</strong></div>
          <div><div className="muted">Equipment</div><strong>{location === "HOME" && noEquipment ? "No equipment" : actualEquipment.filter((item) => item !== "BODYWEIGHT").map((item) => equipmentLabels[item]).join(", ")}</strong></div>
          <div><div className="muted">Experience</div><strong>{experienceOptions.find((item) => item.value === experience)?.title}</strong></div>
          <div><div className="muted">Focus</div><strong>{selectedGroups.length ? selectedGroups.map((group) => `${MUSCLE_GROUP_LABELS[group]} - ${groupPriorities[group] ?? "MEDIUM"}`).join(", ") : "Balanced full body"}</strong></div>
          <div><div className="muted">Training</div><strong>{daysPerWeek} {daysPerWeek === 1 ? "day" : "days"}/week - {durationLabels[sessionDuration]}</strong></div>
        </div>
      </div>
      {error ? <div className="card-flat" style={{ padding: 16, marginTop: 14, color: "var(--danger)" }}>{error}</div> : null}
    </div>
  ];

  return (
    <main className="page" style={{ maxWidth: 900 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 16, marginBottom: 18 }}>
        <BrandLogo href="/" />
        <span className="muted" style={{ fontSize: 13 }}>Step {step + 1} of {totalSteps}</span>
      </div>
      <div className="progress-track" aria-label={`Step ${step + 1} of ${totalSteps}`}><div className="progress-fill" style={{ width: `${((step + 1) / totalSteps) * 100}%` }} /></div>
      <div className="card" style={{ padding: "clamp(20px, 5vw, 42px)", marginTop: 18, minHeight: 470 }}>
        {stepContent[step]}
      </div>
      <div style={{ display: "flex", justifyContent: "space-between", marginTop: 16, gap: 10 }}>
        <Button variant="secondary" disabled={step === 0} onClick={() => { setError(null); setStep((current) => Math.max(0, current - 1)); }}>Back</Button>
        {step === totalSteps - 1 ? <Button disabled={building} onClick={buildProgram}>{building ? "Building..." : "Build My Program"}</Button> : <Button onClick={() => setStep((current) => Math.min(totalSteps - 1, current + 1))}>Continue</Button>}
      </div>
    </main>
  );
}
