"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { storage } from "@/lib/storage";
import type { WorkoutPlan, WorkoutSessionLog } from "@/types/domain";

export function DashboardView() {
  const [plan, setPlan] = useState<WorkoutPlan | null>(null);
  const [sessions, setSessions] = useState<WorkoutSessionLog[]>([]);

  useEffect(() => {
    setPlan(storage.getPlan());
    setSessions(storage.getSessions());
  }, []);

  const thisWeek = useMemo(() => {
    const now = new Date();
    const start = new Date(now);
    start.setDate(now.getDate() - ((now.getDay() + 6) % 7));
    start.setHours(0, 0, 0, 0);
    return sessions.filter((session) => session.completedAt && new Date(session.completedAt) >= start);
  }, [sessions]);

  const nextDay = plan?.days[(thisWeek.length % (plan?.days.length || 1))] ?? null;

  return (
    <div className="stack">
      <div>
        <div className="eyebrow">Gym Trainer</div>
        <h1 className="h2" style={{ margin: "8px 0" }}>Your training, without the guesswork.</h1>
      </div>
      {plan && nextDay ? (
        <div className="card" style={{ padding: 28 }}>
          <div className="eyebrow">Next workout</div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "end", gap: 16, flexWrap: "wrap", marginTop: 8 }}>
            <div>
              <h2 className="h2" style={{ margin: "4px 0" }}>{nextDay.name}</h2>
              <div className="muted">{nextDay.exercises.length} exercises · estimated {nextDay.estimatedMinutes} min</div>
            </div>
            <Link href={`/workout?day=${nextDay.dayIndex}`} className="btn btn-primary">Start Workout</Link>
          </div>
        </div>
      ) : (
        <div className="card" style={{ padding: 28 }}>
          <div className="h2">Build your first program.</div>
          <p className="muted">Tell Gym Trainer where you train, what equipment you have, and what you want to focus on.</p>
          <Link href="/onboarding" className="btn btn-primary">Build My Program</Link>
        </div>
      )}
      <div className="grid-2">
        <div className="card-flat" style={{ padding: 22 }}>
          <div className="eyebrow">This week</div>
          <div className="h2" style={{ marginTop: 8 }}>{thisWeek.length} / {plan?.daysPerWeek ?? 0}</div>
          <div className="muted">workouts completed</div>
        </div>
        <div className="card-flat" style={{ padding: 22 }}>
          <div className="eyebrow">Recent progress</div>
          <div className="h2" style={{ marginTop: 8 }}>{sessions.filter((item) => item.completedAt).length}</div>
          <div className="muted">total workouts completed</div>
        </div>
      </div>
    </div>
  );
}
