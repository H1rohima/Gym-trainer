"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { ExerciseGuide } from "@/components/exercises/ExerciseGuide";
import { storage } from "@/lib/storage";
import type { WorkoutPlan } from "@/types/domain";

function prettyMuscle(value: string) {
  return value.toLowerCase().replaceAll("_", " ").replace(/\b\w/g, (letter) => letter.toUpperCase());
}

export function ProgramView() {
  const [plan, setPlan] = useState<WorkoutPlan | null | undefined>(undefined);
  const [openTechnique, setOpenTechnique] = useState<string | null>(null);

  useEffect(() => setPlan(storage.getPlan()), []);

  if (plan === undefined) return <div className="card-flat" style={{ padding: 24 }}>Loading your program…</div>;
  if (!plan) {
    return (
      <div className="card" style={{ padding: 30 }}>
        <div className="h2">You don&apos;t have a program yet.</div>
        <p className="muted">Complete the short setup to build a plan around your equipment and schedule.</p>
        <Link href="/onboarding" className="btn btn-primary">Build My Program</Link>
      </div>
    );
  }

  return (
    <div className="stack">
      <div className="card" style={{ padding: 28 }}>
        <div className="eyebrow">Active program</div>
        <h1 className="h2" style={{ margin: "8px 0" }}>{plan.name}</h1>
        <p className="muted" style={{ margin: 0 }}>{plan.daysPerWeek} {plan.daysPerWeek === 1 ? "day" : "days"}/week - about {plan.estimatedWeeklyMinutes} min/week - generator {plan.generatorVersion}</p>
      </div>
      {plan.days.map((day) => (
        <section key={day.dayIndex} className="card" style={{ padding: 24 }}>
          <div className="section-title">
            <div>
              <div className="eyebrow">Day {day.dayIndex + 1}</div>
              <h2 className="h2" style={{ margin: "6px 0" }}>{day.name}</h2>
              <div className="muted">{day.focusMuscles.slice(0, 5).map(prettyMuscle).join(" - ")} - estimated {day.estimatedMinutes} min</div>
            </div>
            <Link href={`/workout?day=${day.dayIndex}`} className="btn btn-primary">Start Workout</Link>
          </div>
          <div className="stack" style={{ marginTop: 18 }}>
            {day.exercises.map((exercise) => (
              <div key={exercise.exerciseId} className="card-flat" style={{ padding: 16 }}>
                <div style={{ display: "flex", alignItems: "start", justifyContent: "space-between", gap: 16 }}>
                  <div>
                    <div className="h3">{exercise.order}. {exercise.name}</div>
                    <div className="muted" style={{ marginTop: 5 }}>{exercise.sets} x {exercise.minReps}-{exercise.maxReps} - Rest {exercise.restSeconds}s</div>
                  </div>
                  <span className="pill">{prettyMuscle(exercise.movementPattern)}</span>
                </div>
                <div className="program-exercise-details">
                  <details>
                    <summary style={{ cursor: "pointer", color: "var(--accent)", fontWeight: 700 }}>Why this exercise?</summary>
                    <p className="muted" style={{ lineHeight: 1.55, marginBottom: 0 }}>{exercise.reason}</p>
                  </details>
                  <div>
                    <button
                      type="button"
                      className="details-trigger"
                      aria-expanded={openTechnique === `${day.dayIndex}-${exercise.exerciseId}`}
                      onClick={() => setOpenTechnique((current) => current === `${day.dayIndex}-${exercise.exerciseId}` ? null : `${day.dayIndex}-${exercise.exerciseId}`)}
                    >
                      Technique and instructions
                    </button>
                    {openTechnique === `${day.dayIndex}-${exercise.exerciseId}` ? <div style={{ marginTop: 14 }}><ExerciseGuide exerciseId={exercise.exerciseId} compact /></div> : null}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
      ))}
    </div>
  );
}
