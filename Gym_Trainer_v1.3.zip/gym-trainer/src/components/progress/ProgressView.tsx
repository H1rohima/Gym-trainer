"use client";

import { useEffect, useMemo, useState } from "react";
import { CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { storage } from "@/lib/storage";
import type { WorkoutSessionLog } from "@/types/domain";

function volumeForSession(session: WorkoutSessionLog) {
  return session.exercises.reduce((sessionTotal, exercise) => sessionTotal + exercise.sets.reduce((exerciseTotal, set) => {
    if (!set.completed) return exerciseTotal;
    const weight = set.weight ?? 0;
    const reps = set.reps ?? 0;
    return exerciseTotal + weight * reps;
  }, 0), 0);
}

function currentStreak(sessions: WorkoutSessionLog[]) {
  const days = Array.from(new Set(sessions.filter((item) => item.completedAt).map((item) => new Date(item.completedAt as string).toISOString().slice(0, 10)))).sort().reverse();
  if (days.length === 0) return 0;
  let streak = 1;
  for (let index = 1; index < days.length; index += 1) {
    const previous = new Date(days[index - 1]);
    const current = new Date(days[index]);
    if ((previous.getTime() - current.getTime()) / 86400000 <= 2) streak += 1;
    else break;
  }
  return streak;
}

export function ProgressView() {
  const [sessions, setSessions] = useState<WorkoutSessionLog[]>([]);
  const [exerciseId, setExerciseId] = useState<string>("");

  useEffect(() => setSessions(storage.getSessions().filter((item) => item.completedAt)), []);

  const exercises = useMemo(() => {
    const map = new Map<string, string>();
    sessions.forEach((session) => session.exercises.forEach((exercise) => map.set(exercise.exerciseId, exercise.exerciseName)));
    return Array.from(map.entries()).map(([id, name]) => ({ id, name })).sort((a, b) => a.name.localeCompare(b.name));
  }, [sessions]);

  useEffect(() => {
    if (!exerciseId && exercises[0]) setExerciseId(exercises[0].id);
  }, [exerciseId, exercises]);

  const exerciseData = useMemo(() => sessions
    .slice()
    .reverse()
    .flatMap((session) => {
      const exercise = session.exercises.find((item) => item.exerciseId === exerciseId);
      if (!exercise || !session.completedAt) return [];
      const completed = exercise.sets.filter((set) => set.completed && set.reps !== null);
      if (completed.length === 0) return [];
      const bestWeight = Math.max(...completed.map((set) => set.weight ?? 0));
      const totalVolume = completed.reduce((total, set) => total + (set.weight ?? 0) * (set.reps ?? 0), 0);
      return [{ date: new Date(session.completedAt).toLocaleDateString(undefined, { month: "short", day: "numeric" }), weight: bestWeight, volume: totalVolume }];
    }), [sessions, exerciseId]);

  const thisWeek = useMemo(() => {
    const now = new Date();
    const start = new Date(now);
    start.setDate(now.getDate() - ((now.getDay() + 6) % 7));
    start.setHours(0, 0, 0, 0);
    return sessions.filter((session) => session.completedAt && new Date(session.completedAt) >= start).length;
  }, [sessions]);

  const totalSets = sessions.reduce((total, session) => total + session.exercises.reduce((inner, exercise) => inner + exercise.sets.filter((set) => set.completed).length, 0), 0);
  const totalVolume = Math.round(sessions.reduce((total, session) => total + volumeForSession(session), 0));

  if (sessions.length === 0) {
    return <div className="card" style={{ padding: 30 }}><div className="h2">Complete your first workout to start tracking progress.</div><p className="muted">Your workout history, completed sets, and exercise progression will appear here.</p></div>;
  }

  return (
    <div className="stack">
      <div><div className="eyebrow">Progress</div><h1 className="h2" style={{ margin: "7px 0" }}>Training history</h1></div>
      <div className="grid-3">
        <div className="card-flat" style={{ padding: 20 }}><div className="muted">Workouts completed</div><div className="h2" style={{ marginTop: 8 }}>{sessions.length}</div></div>
        <div className="card-flat" style={{ padding: 20 }}><div className="muted">This week</div><div className="h2" style={{ marginTop: 8 }}>{thisWeek}</div></div>
        <div className="card-flat" style={{ padding: 20 }}><div className="muted">Consistency streak</div><div className="h2" style={{ marginTop: 8 }}>{currentStreak(sessions)}</div></div>
      </div>
      <div className="grid-2">
        <div className="card-flat" style={{ padding: 20 }}><div className="muted">Completed sets</div><div className="h2" style={{ marginTop: 8 }}>{totalSets}</div></div>
        <div className="card-flat" style={{ padding: 20 }}><div className="muted">Logged volume</div><div className="h2" style={{ marginTop: 8 }}>{totalVolume.toLocaleString()} kg·reps</div></div>
      </div>
      <div className="card" style={{ padding: 24 }}>
        <div className="section-title"><div><div className="eyebrow">Exercise progression</div><h2 className="h3" style={{ marginTop: 7 }}>Best working weight over time</h2></div><select className="input" style={{ maxWidth: 260 }} value={exerciseId} onChange={(event) => setExerciseId(event.target.value)}>{exercises.map((exercise) => <option key={exercise.id} value={exercise.id}>{exercise.name}</option>)}</select></div>
        <div style={{ height: 300, width: "100%" }}>
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={exerciseData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
              <CartesianGrid stroke="var(--border)" strokeDasharray="3 3" />
              <XAxis dataKey="date" stroke="var(--muted)" fontSize={12} />
              <YAxis stroke="var(--muted)" fontSize={12} width={40} />
              <Tooltip contentStyle={{ background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 12 }} />
              <Line type="monotone" dataKey="weight" stroke="var(--accent)" strokeWidth={3} dot={{ r: 4 }} name="Weight" />
            </LineChart>
          </ResponsiveContainer>
        </div>
        {exerciseData.length === 0 ? <div className="muted">This exercise does not have enough logged weight data yet.</div> : null}
      </div>
      <div className="card-flat" style={{ padding: 20 }}>
        <div className="h3">Recent workouts</div>
        <div className="stack" style={{ marginTop: 12 }}>{sessions.slice(0, 6).map((session) => <div key={session.id} style={{ display: "flex", justifyContent: "space-between", gap: 12, paddingBottom: 10, borderBottom: "1px solid var(--border)" }}><div><strong>{session.dayName}</strong><div className="muted">{new Date(session.completedAt as string).toLocaleDateString()}</div></div><div className="muted">{Math.round(session.durationSeconds / 60)} min</div></div>)}</div>
      </div>
    </div>
  );
}
