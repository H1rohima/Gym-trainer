"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { storage } from "@/lib/storage";
import type { UserProfile } from "@/types/domain";

export function SettingsView() {
  const [theme, setTheme] = useState<"light" | "dark" | "system">("system");
  const [profile, setProfile] = useState<UserProfile | null>(null);

  useEffect(() => {
    setTheme(storage.getTheme());
    setProfile(storage.getProfile());
  }, []);

  function changeTheme(value: "light" | "dark" | "system") {
    setTheme(value);
    storage.setTheme(value);
    if (value === "system") document.documentElement.removeAttribute("data-theme");
    else document.documentElement.dataset.theme = value;
  }

  return (
    <div className="stack" style={{ maxWidth: 820 }}>
      <div><div className="eyebrow">Settings</div><h1 className="h2" style={{ margin: "7px 0" }}>Keep it simple.</h1></div>
      <section className="card" style={{ padding: 24 }}>
        <div className="h3">Appearance</div>
        <div style={{ display: "flex", gap: 8, marginTop: 14, flexWrap: "wrap" }}>{(["light", "dark", "system"] as const).map((value) => <button key={value} className={`pill ${theme === value ? "pill-selected" : ""}`} onClick={() => changeTheme(value)}>{value[0].toUpperCase() + value.slice(1)}</button>)}</div>
      </section>
      <section className="card" style={{ padding: 24 }}>
        <div className="h3">Training preferences</div>
        {profile ? <div className="grid-2" style={{ marginTop: 16 }}><div><div className="muted">Goal</div><strong>{profile.goal.replaceAll("_", " ")}</strong></div><div><div className="muted">Location</div><strong>{profile.location}</strong></div><div><div className="muted">Experience</div><strong>{profile.experience}</strong></div><div><div className="muted">Schedule</div><strong>{profile.daysPerWeek} {profile.daysPerWeek === 1 ? "day" : "days"}/week</strong></div></div> : <p className="muted">No preferences saved yet.</p>}
        <Link className="btn btn-secondary" style={{ marginTop: 18 }} href="/onboarding">Edit Preferences</Link>
      </section>
      <section className="card" style={{ padding: 24 }}>
        <div className="h3">Program</div>
        <p className="muted">Changing important training preferences creates a new program instead of silently changing the current plan.</p>
        <Link className="btn btn-primary" href="/onboarding">Rebuild Program</Link>
      </section>
    </div>
  );
}
