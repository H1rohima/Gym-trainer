"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { ExerciseGuide } from "@/components/exercises/ExerciseGuide";
import { progressionMessage, getProgressionRecommendation } from "@/lib/progression/getProgressionRecommendation";
import { storage } from "@/lib/storage";
import type { ExerciseLog, SetLog, WorkoutPlan, WorkoutSessionLog } from "@/types/domain";

function initializeLogs(plan: WorkoutPlan, dayIndex: number): ExerciseLog[] {
  const day = plan.days[dayIndex];
  if (!day) return [];
  return day.exercises.map((exercise) => ({
    exerciseId: exercise.exerciseId,
    exerciseName: exercise.name,
    targetMinReps: exercise.minReps,
    targetMaxReps: exercise.maxReps,
    sets: Array.from({ length: exercise.sets }, (_, index) => ({ setNumber: index + 1, weight: null, reps: null, completed: false }))
  }));
}

function formatDuration(seconds: number) {
  const minutes = Math.floor(seconds / 60);
  const remaining = seconds % 60;
  return `${minutes}:${remaining.toString().padStart(2, "0")}`;
}

export function WorkoutSession() {
  const [plan, setPlan] = useState<WorkoutPlan | null>(null);
  const [dayIndex, setDayIndex] = useState(0);
  const [exerciseIndex, setExerciseIndex] = useState(0);
  const [logs, setLogs] = useState<ExerciseLog[]>([]);
  const [startedAt, setStartedAt] = useState<Date | null>(null);
  const [elapsed, setElapsed] = useState(0);
  const [rest, setRest] = useState(0);
  const [finished, setFinished] = useState<WorkoutSessionLog | null>(null);
  const [showTechnique, setShowTechnique] = useState(false);
  const [history, setHistory] = useState<WorkoutSessionLog[]>([]);

  useEffect(() => {
    const storedPlan = storage.getPlan();
    const params = new URLSearchParams(window.location.search);
    const requested = Number(params.get("day") ?? 0);
    const safeDay = storedPlan && requested >= 0 && requested < storedPlan.days.length ? requested : 0;
    setPlan(storedPlan);
    setDayIndex(safeDay);
    setLogs(storedPlan ? initializeLogs(storedPlan, safeDay) : []);
    setHistory(storage.getSessions());
    setStartedAt(new Date());
  }, []);

  useEffect(() => {
    if (!startedAt || finished) return;
    const interval = window.setInterval(() => setElapsed(Math.floor((Date.now() - startedAt.getTime()) / 1000)), 1000);
    return () => window.clearInterval(interval);
  }, [startedAt, finished]);

  useEffect(() => {
    if (rest <= 0) return;
    const interval = window.setInterval(() => setRest((value) => Math.max(0, value - 1)), 1000);
    return () => window.clearInterval(interval);
  }, [rest]);

  const day = plan?.days[dayIndex] ?? null;
  const currentPlanExercise = day?.exercises[exerciseIndex] ?? null;
  const currentLog = logs[exerciseIndex] ?? null;

  const previousLog = useMemo(() => {
    if (!currentPlanExercise) return null;
    for (const session of history) {
      const match = session.exercises.find((exercise) => exercise.exerciseId === currentPlanExercise.exerciseId);
      if (match) return match;
    }
    return null;
  }, [currentPlanExercise, history]);

  function updateSet(setIndex: number, patch: Partial<SetLog>) {
    setLogs((current) => current.map((exercise, eIndex) => eIndex === exerciseIndex ? {
      ...exercise,
      sets: exercise.sets.map((set, sIndex) => sIndex === setIndex ? { ...set, ...patch } : set)
    } : exercise));
  }

  function toggleDone(setIndex: number) {
    if (!currentPlanExercise || !currentLog) return;
    const nextDone = !currentLog.sets[setIndex].completed;
    updateSet(setIndex, { completed: nextDone });
    if (nextDone) setRest(currentPlanExercise.restSeconds);
  }

  function finishWorkout() {
    if (!plan || !day || !startedAt) return;
    const completedAt = new Date();
    const session: WorkoutSessionLog = {
      id: `session-${completedAt.getTime()}`,
      planId: plan.id,
      dayIndex,
      dayName: day.name,
      startedAt: startedAt.toISOString(),
      completedAt: completedAt.toISOString(),
      durationSeconds: Math.max(1, Math.floor((completedAt.getTime() - startedAt.getTime()) / 1000)),
      exercises: logs
    };
    storage.addSession(session);
    setFinished(session);
    setElapsed(session.durationSeconds);
  }

  if (!plan) {
    return (
      <div className="card" style={{ padding: 28 }}>
        <div className="h2">No workout is ready yet.</div>
        <p className="muted">Build a program first, then start one of its workout days.</p>
        <Link className="btn btn-primary" href="/onboarding">Build My Program</Link>
      </div>
    );
  }

  if (!day || !currentPlanExercise || !currentLog) return <div className="card-flat" style={{ padding: 24 }}>This workout could not be loaded.</div>;

  if (finished) {
    const totalSets = finished.exercises.reduce((total, exercise) => total + exercise.sets.filter((set) => set.completed).length, 0);
    return (
      <div className="card" style={{ padding: 30, maxWidth: 720, margin: "0 auto" }}>
        <div className="eyebrow">Workout complete</div>
        <h1 className="h2" style={{ margin: "8px 0 20px" }}>{finished.dayName}</h1>
        <div className="grid-3">
          <div className="card-flat" style={{ padding: 18 }}><div className="muted">Duration</div><div className="h3" style={{ marginTop: 6 }}>{formatDuration(finished.durationSeconds)}</div></div>
          <div className="card-flat" style={{ padding: 18 }}><div className="muted">Exercises</div><div className="h3" style={{ marginTop: 6 }}>{finished.exercises.length}</div></div>
          <div className="card-flat" style={{ padding: 18 }}><div className="muted">Completed sets</div><div className="h3" style={{ marginTop: 6 }}>{totalSets}</div></div>
        </div>
        <div className="stack" style={{ marginTop: 20 }}>
          {finished.exercises.map((exercise) => {
            const recommendation = getProgressionRecommendation(exercise.sets, exercise.targetMinReps, exercise.targetMaxReps);
            return <div key={exercise.exerciseId} className="card-flat" style={{ padding: 16 }}><strong>{exercise.exerciseName}</strong><div className="muted" style={{ marginTop: 5 }}>{progressionMessage(recommendation)}</div></div>;
          })}
        </div>
        <div style={{ display: "flex", gap: 10, marginTop: 22, flexWrap: "wrap" }}>
          <Link className="btn btn-primary" href="/progress">View Progress</Link>
          <Link className="btn btn-secondary" href="/program">Back to Program</Link>
        </div>
      </div>
    );
  }

  const completedSets = logs.reduce((total, exercise) => total + exercise.sets.filter((set) => set.completed).length, 0);
  const totalSets = logs.reduce((total, exercise) => total + exercise.sets.length, 0);

  return (
    <div style={{ maxWidth: 820, margin: "0 auto" }}>
      <div style={{ display: "flex", justifyContent: "space-between", gap: 16, alignItems: "end", marginBottom: 18 }}>
        <div>
          <div className="eyebrow">{day.name}</div>
          <h1 className="h2" style={{ margin: "5px 0" }}>Exercise {exerciseIndex + 1} of {day.exercises.length}</h1>
          <div className="muted">{formatDuration(elapsed)} - {completedSets}/{totalSets} sets completed</div>
        </div>
        {rest > 0 ? <div className="pill pill-selected">Rest {rest}s</div> : null}
      </div>
      <div className="progress-track" style={{ marginBottom: 18 }}><div className="progress-fill" style={{ width: `${((exerciseIndex + 1) / day.exercises.length) * 100}%` }} /></div>
      <div className="card" style={{ padding: "clamp(18px, 4vw, 30px)" }}>
        <div className="eyebrow">{currentPlanExercise.primaryMuscles.map((value) => value.replaceAll("_", " ")).join(" - ")}</div>
        <h2 className="h2" style={{ margin: "8px 0" }}>{currentPlanExercise.name}</h2>
        <p className="muted">Target {currentPlanExercise.sets} x {currentPlanExercise.minReps}-{currentPlanExercise.maxReps} - Rest {currentPlanExercise.restSeconds}s</p>
        <div className="technique-details" style={{ margin: "18px 0" }}>
          <button type="button" className="details-trigger" aria-expanded={showTechnique} onClick={() => setShowTechnique((value) => !value)}>How to perform this exercise</button>
          {showTechnique ? <div style={{ marginTop: 14 }}><ExerciseGuide exerciseId={currentPlanExercise.exerciseId} compact /></div> : null}
        </div>
        {previousLog ? (
          <div className="card-flat" style={{ padding: 14, margin: "18px 0" }}>
            <div className="muted" style={{ fontSize: 13 }}>Previous workout</div>
            <div style={{ marginTop: 6, fontWeight: 650 }}>{previousLog.sets.filter((set) => set.completed).map((set) => `${set.weight ?? "Bodyweight"}${set.weight !== null ? " kg" : ""} x ${set.reps ?? "-"}`).join(" - ") || "No completed sets"}</div>
          </div>
        ) : null}
        <div className="table-wrap">
          <table>
            <thead><tr><th>Set</th><th>Weight</th><th>Reps</th><th>Done</th></tr></thead>
            <tbody>
              {currentLog.sets.map((set, setIndex) => (
                <tr key={set.setNumber}>
                  <td>{set.setNumber}</td>
                  <td><input className="input" style={{ width: 100, minHeight: 38 }} inputMode="decimal" aria-label={`Weight for set ${set.setNumber}`} value={set.weight ?? ""} placeholder="kg" onChange={(event) => updateSet(setIndex, { weight: event.target.value === "" ? null : Number(event.target.value) })} /></td>
                  <td><input className="input" style={{ width: 88, minHeight: 38 }} inputMode="numeric" aria-label={`Reps for set ${set.setNumber}`} value={set.reps ?? ""} placeholder="reps" onChange={(event) => updateSet(setIndex, { reps: event.target.value === "" ? null : Number(event.target.value) })} /></td>
                  <td><button className={`pill ${set.completed ? "pill-selected" : ""}`} onClick={() => toggleDone(setIndex)} aria-pressed={set.completed}>{set.completed ? "Done" : "Mark"}</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <details style={{ marginTop: 18 }}><summary style={{ cursor: "pointer", color: "var(--accent)", fontWeight: 700 }}>Why this exercise?</summary><p className="muted">{currentPlanExercise.reason}</p></details>
      </div>
      <div style={{ display: "flex", justifyContent: "space-between", gap: 10, marginTop: 16, flexWrap: "wrap" }}>
        <button className="btn btn-secondary" disabled={exerciseIndex === 0} onClick={() => { setShowTechnique(false); setExerciseIndex((value) => Math.max(0, value - 1)); }}>Previous Exercise</button>
        <div style={{ display: "flex", gap: 10 }}>
          {exerciseIndex < day.exercises.length - 1 ? <button className="btn btn-primary" onClick={() => { setShowTechnique(false); setExerciseIndex((value) => Math.min(day.exercises.length - 1, value + 1)); }}>Next Exercise</button> : <button className="btn btn-primary" onClick={finishWorkout}>Finish Workout</button>}
        </div>
      </div>
    </div>
  );
}
