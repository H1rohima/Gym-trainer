import type { Experience, Goal, MusclePriority, SessionDuration, UserProfile } from "@/types/domain";

type UserProfileDays = UserProfile["daysPerWeek"];

export const GENERATOR_VERSION = "1.1";

export const PRIORITY_WEIGHTS: Record<MusclePriority, number> = {
  LOW: 0.75,
  MEDIUM: 1,
  HIGH: 1.35
};

export const MUSCLE_ROLE_WEIGHTS = {
  PRIMARY: 1,
  SECONDARY: 0.35
} as const;

export const TARGET_MINUTES: Record<SessionDuration, number> = {
  SHORT: 25,
  MEDIUM: 38,
  STANDARD: 52,
  LONG: 70
};

export const BASE_EXERCISE_COUNT: Record<SessionDuration, number> = {
  SHORT: 4,
  MEDIUM: 6,
  STANDARD: 7,
  LONG: 8
};


export const FREQUENCY_EXERCISE_MODIFIER: Record<UserProfileDays, number> = {
  1: 1,
  2: 0,
  3: 0,
  4: 0,
  5: -1,
  6: -1,
  7: -2
};

export const EXPERIENCE_VOLUME_FACTOR: Record<Experience, number> = {
  BEGINNER: 0.85,
  INTERMEDIATE: 1,
  ADVANCED: 1.1
};

export const GOAL_SCORE_BONUS: Record<Goal, number> = {
  HYPERTROPHY: 2,
  STRENGTH: 2.2,
  GENERAL_FITNESS: 1.5
};

export const SCORING = {
  primaryMuscle: 4,
  secondaryMuscle: 1.4,
  highPriority: 1.6,
  mediumPriority: 1,
  lowPriority: 0.6,
  compound: 1.1,
  movementCoverage: 1.2,
  duplicatePatternPenalty: 1.75,
  isolationPenaltyForShortSession: 0.9,
  equipmentSimplicity: 0.15,
  weeklyRepeatPenalty: 2.4
} as const;

export const ACTIVE_SET_SECONDS = 45;
export const TRANSITION_SECONDS = 75;
