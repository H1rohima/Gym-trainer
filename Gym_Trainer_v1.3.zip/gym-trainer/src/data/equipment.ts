import type { EquipmentCode } from "@/types/domain";

export const EQUIPMENT: Array<{ code: EquipmentCode; displayName: string }> = [
  { code: "BODYWEIGHT", displayName: "Bodyweight" },
  { code: "PULL_UP_BAR", displayName: "Pull-Up Bar" },
  { code: "DUMBBELL", displayName: "Dumbbells" },
  { code: "KETTLEBELL", displayName: "Kettlebell" },
  { code: "BARBELL", displayName: "Barbell" },
  { code: "BENCH", displayName: "Bench" },
  { code: "CABLE", displayName: "Cable" },
  { code: "MACHINE", displayName: "Machine" },
  { code: "BANDS", displayName: "Resistance Bands" },
  { code: "OTHER", displayName: "Other" }
];

export const HOME_EQUIPMENT: EquipmentCode[] = ["PULL_UP_BAR", "DUMBBELL", "KETTLEBELL", "BENCH", "BANDS"];
export const BASIC_GYM_EQUIPMENT: EquipmentCode[] = ["BODYWEIGHT", "PULL_UP_BAR", "DUMBBELL", "BARBELL", "BENCH", "CABLE"];
export const FULL_GYM_EQUIPMENT: EquipmentCode[] = ["BODYWEIGHT", "PULL_UP_BAR", "DUMBBELL", "KETTLEBELL", "BARBELL", "BENCH", "CABLE", "MACHINE", "BANDS"];
