export interface ExerciseVideo {
  youtubeId: string;
  title: string;
  channel: string;
}

export const EXERCISE_VIDEOS: Partial<Record<string, ExerciseVideo>> = {
  EX031: {
    youtubeId: "l6-aIZTbAR0",
    title: "Pull-Up Technique Tutorial",
    channel: "Summerfunfitness"
  },
  EX039: {
    youtubeId: "MeyuOEimrC0",
    title: "Dumbbell Bench Press: Complete Tutorial",
    channel: "Ninolift"
  },
  EX043: {
    youtubeId: "W5PVRG2C32s",
    title: "How to Dumbbell Shoulder Press",
    channel: "REP University"
  },
  EX080: {
    youtubeId: "hWbUlkb5Ms4",
    title: "How To Bench Press With Perfect Technique",
    channel: "Jeff Nippard"
  },
  EX086: {
    youtubeId: "5bJEigM5iVg",
    title: "Romanian Deadlift Tutorial",
    channel: "Squat University"
  },
  EX095: {
    youtubeId: "43hWj8mfYGY",
    title: "How to do the Lat Pulldown",
    channel: "Max Euceda"
  }
};
