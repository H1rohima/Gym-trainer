import type { MuscleCode } from "@/types/domain";

export const MUSCLES: Array<{ code: MuscleCode; displayName: string; onboardingGroup: string }> = [
  { code: "CHEST", displayName: "Chest", onboardingGroup: "Chest" },
  { code: "FRONT_DELTS", displayName: "Front Delts", onboardingGroup: "Shoulders" },
  { code: "SIDE_DELTS", displayName: "Side Delts", onboardingGroup: "Shoulders" },
  { code: "REAR_DELTS", displayName: "Rear Delts", onboardingGroup: "Shoulders" },
  { code: "BICEPS", displayName: "Biceps", onboardingGroup: "Biceps" },
  { code: "TRICEPS", displayName: "Triceps", onboardingGroup: "Triceps" },
  { code: "FOREARMS", displayName: "Forearms", onboardingGroup: "Forearms" },
  { code: "ABS", displayName: "Abs", onboardingGroup: "Abs" },
  { code: "OBLIQUES", displayName: "Obliques", onboardingGroup: "Obliques" },
  { code: "UPPER_BACK", displayName: "Upper Back", onboardingGroup: "Upper Back" },
  { code: "LATS", displayName: "Lats", onboardingGroup: "Lats" },
  { code: "LOWER_BACK", displayName: "Lower Back", onboardingGroup: "Lower Back" },
  { code: "GLUTES", displayName: "Glutes", onboardingGroup: "Glutes" },
  { code: "QUADS", displayName: "Quads", onboardingGroup: "Quads" },
  { code: "HAMSTRINGS", displayName: "Hamstrings", onboardingGroup: "Hamstrings" },
  { code: "CALVES", displayName: "Calves", onboardingGroup: "Calves" }
];

export const ONBOARDING_MUSCLE_GROUPS = [
  "CHEST",
  "SHOULDERS",
  "BICEPS",
  "TRICEPS",
  "FOREARMS",
  "ABS",
  "OBLIQUES",
  "UPPER_BACK",
  "LATS",
  "LOWER_BACK",
  "GLUTES",
  "QUADS",
  "HAMSTRINGS",
  "CALVES"
] as const;
