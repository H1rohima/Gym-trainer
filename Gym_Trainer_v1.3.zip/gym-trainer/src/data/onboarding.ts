import type { MuscleCode } from "@/types/domain";

export type OnboardingMuscleGroup =
  | "CHEST"
  | "SHOULDERS"
  | "BICEPS"
  | "TRICEPS"
  | "FOREARMS"
  | "ABS"
  | "OBLIQUES"
  | "UPPER_BACK"
  | "LATS"
  | "LOWER_BACK"
  | "GLUTES"
  | "QUADS"
  | "HAMSTRINGS"
  | "CALVES";

export const MUSCLE_GROUP_LABELS: Record<OnboardingMuscleGroup, string> = {
  CHEST: "Chest",
  SHOULDERS: "Shoulders",
  BICEPS: "Biceps",
  TRICEPS: "Triceps",
  FOREARMS: "Forearms",
  ABS: "Abs",
  OBLIQUES: "Obliques",
  UPPER_BACK: "Upper Back",
  LATS: "Lats",
  LOWER_BACK: "Lower Back",
  GLUTES: "Glutes",
  QUADS: "Quads",
  HAMSTRINGS: "Hamstrings",
  CALVES: "Calves"
};

export const GROUP_TO_MUSCLES: Record<OnboardingMuscleGroup, MuscleCode[]> = {
  CHEST: ["CHEST"],
  SHOULDERS: ["FRONT_DELTS", "SIDE_DELTS", "REAR_DELTS"],
  BICEPS: ["BICEPS"],
  TRICEPS: ["TRICEPS"],
  FOREARMS: ["FOREARMS"],
  ABS: ["ABS"],
  OBLIQUES: ["OBLIQUES"],
  UPPER_BACK: ["UPPER_BACK"],
  LATS: ["LATS"],
  LOWER_BACK: ["LOWER_BACK"],
  GLUTES: ["GLUTES"],
  QUADS: ["QUADS"],
  HAMSTRINGS: ["HAMSTRINGS"],
  CALVES: ["CALVES"]
};
