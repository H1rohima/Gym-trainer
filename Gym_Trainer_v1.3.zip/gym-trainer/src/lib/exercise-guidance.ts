import type { Exercise } from "@/types/domain";

function pretty(value: string) {
  return value.toLowerCase().replaceAll("_", " ").replace(/\b\w/g, (letter) => letter.toUpperCase());
}

export function buildExerciseOverview(exercise: Exercise): string {
  const kind = exercise.compound ? "compound" : "isolation";
  const side = exercise.unilateral ? "unilateral " : "";
  const primary = exercise.primaryMuscles.map(pretty).join(" and ");
  const secondary = exercise.secondaryMuscles.length ? ` It also involves ${exercise.secondaryMuscles.map(pretty).join(", ")}.` : "";
  const equipment = exercise.requiredEquipment.map(pretty).join(", ");
  return `${exercise.name} is a ${side}${kind} ${pretty(exercise.movementPattern).toLowerCase()} exercise that primarily targets ${primary}.${secondary} It uses ${equipment} and is classified as ${pretty(exercise.difficulty).toLowerCase()} difficulty.`;
}
