import type { Exercise } from "@/types/domain";

export interface ResolvedExerciseVideo {
  youtubeId: string;
  title: string;
  channel: string;
  startSeconds?: number;
  matchType: "curated" | "exact" | "close";
}

interface ExercemusExercise {
  name: string;
  aliases?: string[];
  equipment?: string[];
  primary_muscles?: string[];
  secondary_muscles?: string[];
  video?: string;
}

interface ExercemusDataset {
  exercises?: ExercemusExercise[];
}

interface WorkoutDatabaseVideo {
  youtube_id?: string;
  priority?: number;
  start_seconds?: number;
  channel?: string;
}

interface WorkoutDatabaseExercise {
  exercise_name?: { en?: string };
  aliases?: string[];
  material?: { id?: string; name?: { en?: string } };
  target_muscles?: { primary?: string[]; secondary?: string[] };
  media?: { videos?: WorkoutDatabaseVideo[] };
}

interface VideoCandidate {
  name: string;
  aliases: string[];
  equipment: string[];
  muscles: string[];
  youtubeId: string;
  channel: string;
  startSeconds?: number;
  sourcePriority: number;
}

const EXERCEMUS_URL = "https://raw.githubusercontent.com/exercemus/exercises/minified/minified-exercises.json";
const WORKOUT_DATABASE_BASE_URL = "https://raw.githubusercontent.com/rthepen/workout-database/main/data";

const workoutEquipmentSources: Record<string, string> = {
  BODYWEIGHT: "bodyweight",
  DUMBBELL: "dumbbells",
  KETTLEBELL: "kettlebell",
  BARBELL: "barbell",
  BANDS: "resistance_band",
  PULL_UP_BAR: "bodyweight"
};

const equipmentTerms: Record<string, string[]> = {
  BODYWEIGHT: ["none", "bodyweight", "body weight"],
  DUMBBELL: ["dumbbell", "dumbbells"],
  KETTLEBELL: ["kettlebell"],
  BARBELL: ["barbell"],
  CABLE: ["cable"],
  MACHINE: ["machine"],
  PULL_UP_BAR: ["pull-up bar", "pull up bar"],
  BANDS: ["bands", "band", "resistance band"],
  BENCH: ["bench", "incline bench"]
};

const muscleTerms: Record<string, string[]> = {
  CHEST: ["chest", "pectorals", "pectoralis"],
  FRONT_DELTS: ["shoulders", "front delts", "anterior deltoid"],
  SIDE_DELTS: ["shoulders", "side delts", "lateral deltoid"],
  REAR_DELTS: ["shoulders", "rear delts", "posterior deltoid"],
  BICEPS: ["biceps", "biceps brachii"],
  TRICEPS: ["triceps"],
  FOREARMS: ["forearms"],
  ABS: ["abs", "rectus abdominis", "core"],
  OBLIQUES: ["obliques", "core"],
  UPPER_BACK: ["middle back", "upper back", "rhomboids", "trapezius", "traps"],
  LATS: ["lats", "latissimus dorsi"],
  LOWER_BACK: ["lower back", "erector spinae"],
  GLUTES: ["glutes", "gluteus maximus"],
  QUADS: ["quads", "quadriceps"],
  HAMSTRINGS: ["hamstrings"],
  CALVES: ["calves", "gastrocnemius", "soleus"]
};

const nameAliases: Record<string, string[]> = {
  "box squat to bench": ["box squat", "bench squat"],
  "bodyweight sissy squat": ["sissy squat"],
  "single leg glute bridge": ["single leg bridge", "one leg glute bridge"],
  "frog pump": ["frog pumps"],
  "standing calf raise": ["calf raise"],
  "single leg calf raise": ["one leg calf raise"],
  "hollow body hold": ["hollow hold"],
  "negative pull up": ["negative chin up", "eccentric pull up"],
  "scapular pull up": ["scap pull up", "scapular pullup"],
  "dumbbell rear delt raise": ["bent over dumbbell reverse fly", "dumbbell rear delt fly"],
  "one arm dumbbell row": ["one arm dumbbell row", "single arm dumbbell row"],
  "chest supported dumbbell row": ["incline dumbbell row", "chest supported row"],
  "dumbbell overhead triceps extension": ["dumbbell triceps extension", "seated triceps press"],
  "dumbbell skull crusher": ["dumbbell lying triceps extension", "dumbbell french press"],
  "dumbbell kickback": ["triceps kickback"],
  "dumbbell front squat": ["dumbbell squat"],
  "dumbbell split squat": ["dumbbell stationary lunge", "dumbbell split squat"],
  "dumbbell romanian deadlift": ["dumbbell stiff leg deadlift", "dumbbell romanian deadlift"],
  "kettlebell romanian deadlift": ["kettlebell stiff leg deadlift", "kettlebell romanian deadlift"],
  "kettlebell front rack squat": ["kettlebell front squat", "double kettlebell front squat"],
  "kettlebell farmer carry": ["kettlebell farmers walk", "farmers walk"],
  "kettlebell suitcase carry": ["kettlebell suitcase walk", "suitcase carry"],
  "barbell overhead press": ["military press", "barbell shoulder press", "overhead press"],
  "conventional deadlift": ["barbell deadlift", "deadlift"],
  "barbell row": ["bent over barbell row", "bent over row"],
  "barbell hip thrust": ["hip thrust", "barbell glute bridge"],
  "reverse barbell curl": ["reverse curl", "reverse barbell curl"],
  "barbell skull crusher": ["lying triceps press", "barbell lying triceps extension", "skullcrusher"],
  "close grip lat pulldown": ["close grip front lat pulldown", "close grip pulldown"],
  "seated cable row": ["seated row", "cable seated row"],
  "single arm cable row": ["one arm cable row", "single arm seated cable row"],
  "cable rear delt fly": ["cable reverse fly", "rear delt cable fly"],
  "triceps pushdown": ["triceps pushdown", "cable triceps pushdown"],
  "overhead cable triceps extension": ["cable overhead triceps extension", "overhead triceps extension"],
  "straight arm pulldown": ["straight arm cable pulldown", "straight arm lat pulldown"],
  "pallof press": ["pallof press", "cable anti rotation press"],
  "machine chest press": ["chest press machine", "machine bench press", "leverage chest press"],
  "incline machine chest press": ["incline chest press machine", "incline machine press"],
  "machine shoulder press": ["shoulder press machine", "machine shoulder press"],
  "pec deck": ["butterfly", "pec deck fly", "machine fly"],
  "reverse pec deck": ["reverse machine fly", "reverse pec deck fly", "rear delt machine fly"],
  "machine row": ["seated row machine", "machine row"],
  "assisted pull up": ["assisted pull up", "machine assisted pull up"],
  "hack squat": ["hack squat machine", "hack squat"],
  "leg extension": ["leg extensions", "machine leg extension"],
  "seated leg curl": ["seated leg curl", "seated hamstring curl"],
  "lying leg curl": ["lying leg curl", "lying hamstring curl"],
  "hip abduction machine": ["thigh abductor", "hip abductor machine", "seated hip abduction"],
  "seated calf raise machine": ["seated calf raise", "calf raise machine"],
  "machine preacher curl": ["preacher curl machine", "machine preacher curl"],
  "machine triceps extension": ["triceps extension machine", "machine triceps extension"],
  "band chest press": ["resistance band chest press", "band chest press"],
  "band row": ["resistance band row", "band row"],
  "band lat pulldown": ["resistance band lat pulldown", "band pulldown"],
  "band shoulder press": ["resistance band shoulder press", "band shoulder press"],
  "band lateral raise": ["resistance band lateral raise", "band lateral raise"],
  "band face pull": ["resistance band face pull", "band face pull"],
  "band biceps curl": ["resistance band biceps curl", "band bicep curl"],
  "band triceps pushdown": ["resistance band triceps pushdown", "band triceps extension"],
  "band squat": ["resistance band squat", "band squat"],
  "band romanian deadlift": ["resistance band romanian deadlift", "band stiff leg deadlift", "band good morning"]
};

function normalize(value: string) {
  return value
    .toLowerCase()
    .replace(/&/g, " and ")
    .replace(/pushups/g, "push up")
    .replace(/pullups/g, "pull up")
    .replace(/chinups/g, "chin up")
    .replace(/pulldown/g, "pull down")
    .replace(/one arm/g, "single arm")
    .replace(/one leg/g, "single leg")
    .replace(/bicep\b/g, "biceps")
    .replace(/tricep\b/g, "triceps")
    .replace(/rear delt/g, "rear deltoid")
    .replace(/front delt/g, "front deltoid")
    .replace(/side delt/g, "lateral deltoid")
    .replace(/[^a-z0-9]+/g, " ")
    .trim()
    .replace(/\s+/g, " ");
}

function tokenSet(value: string) {
  const ignored = new Set(["the", "with", "and", "to", "a", "an", "of", "on", "exercise", "machine"]);
  return new Set(normalize(value).split(" ").filter((token) => token.length > 1 && !ignored.has(token)));
}

function similarity(a: string, b: string) {
  const aa = tokenSet(a);
  const bb = tokenSet(b);
  if (!aa.size || !bb.size) return 0;
  let intersection = 0;
  aa.forEach((token) => {
    if (bb.has(token)) intersection += 1;
  });
  const union = new Set([...aa, ...bb]).size;
  return intersection / union;
}

function parseYouTubeUrl(url: string) {
  try {
    const parsed = new URL(url);
    let youtubeId = "";
    if (parsed.hostname.includes("youtu.be")) youtubeId = parsed.pathname.replace("/", "");
    if (parsed.hostname.includes("youtube.com")) youtubeId = parsed.searchParams.get("v") ?? parsed.pathname.split("/embed/")[1] ?? "";
    if (!youtubeId) return null;
    const rawStart = parsed.searchParams.get("t") ?? parsed.searchParams.get("start") ?? "";
    const startSeconds = /^\d+$/.test(rawStart) ? Number(rawStart) : /^\d+s$/.test(rawStart) ? Number(rawStart.slice(0, -1)) : undefined;
    return { youtubeId, startSeconds };
  } catch {
    return null;
  }
}

function buildCandidates(exercemus: ExercemusDataset | null, workoutDatabase: WorkoutDatabaseExercise[] | null) {
  const candidates: VideoCandidate[] = [];

  exercemus?.exercises?.forEach((item) => {
    if (!item.video) return;
    const parsed = parseYouTubeUrl(item.video);
    if (!parsed) return;
    candidates.push({
      name: item.name,
      aliases: item.aliases ?? [],
      equipment: item.equipment ?? [],
      muscles: [...(item.primary_muscles ?? []), ...(item.secondary_muscles ?? [])],
      youtubeId: parsed.youtubeId,
      startSeconds: parsed.startSeconds,
      channel: "YouTube",
      sourcePriority: 1
    });
  });

  workoutDatabase?.forEach((item) => {
    const videos = [...(item.media?.videos ?? [])]
      .filter((video) => video.youtube_id)
      .sort((a, b) => (a.priority ?? 99) - (b.priority ?? 99));
    const video = videos[0];
    const name = item.exercise_name?.en;
    if (!video?.youtube_id || !name) return;
    candidates.push({
      name,
      aliases: item.aliases ?? [],
      equipment: [item.material?.id ?? "", item.material?.name?.en ?? ""].filter(Boolean),
      muscles: [...(item.target_muscles?.primary ?? []), ...(item.target_muscles?.secondary ?? [])],
      youtubeId: video.youtube_id,
      startSeconds: video.start_seconds,
      channel: video.channel ?? "YouTube",
      sourcePriority: 2
    });
  });

  return candidates;
}

function scoreCandidate(exercise: Exercise, candidate: VideoCandidate) {
  const targetName = normalize(exercise.name);
  const aliases = nameAliases[targetName] ?? [];
  const targetNames = [exercise.name, ...aliases];
  const candidateNames = [candidate.name, ...candidate.aliases];

  let score = 0;
  let exact = false;

  targetNames.forEach((target) => {
    candidateNames.forEach((candidateName) => {
      const a = normalize(target);
      const b = normalize(candidateName);
      if (a === b) {
        score = Math.max(score, 120);
        exact = true;
        return;
      }
      if (a.includes(b) || b.includes(a)) score = Math.max(score, 82);
      score = Math.max(score, similarity(a, b) * 72);
    });
  });

  const candidateEquipment = candidate.equipment.map(normalize);
  const requiredEquipment = exercise.requiredEquipment.flatMap((item) => equipmentTerms[item] ?? [item]).map(normalize);
  if (requiredEquipment.some((required) => candidateEquipment.some((item) => item.includes(required) || required.includes(item)))) score += 16;

  const candidateMuscles = candidate.muscles.map(normalize);
  const primaryMuscles = exercise.primaryMuscles.flatMap((item) => muscleTerms[item] ?? [item]).map(normalize);
  if (primaryMuscles.some((muscle) => candidateMuscles.some((item) => item.includes(muscle) || muscle.includes(item)))) score += 14;

  score += candidate.sourcePriority;
  return { score, exact };
}

let exercemusCache: Promise<ExercemusDataset | null> | null = null;
const workoutDatabaseCache = new Map<string, Promise<WorkoutDatabaseExercise[] | null>>();

function loadExercemus() {
  if (!exercemusCache) {
    exercemusCache = fetch(EXERCEMUS_URL, { cache: "force-cache" })
      .then((response) => response.ok ? response.json() as Promise<ExercemusDataset> : null)
      .catch(() => null);
  }
  return exercemusCache;
}

function loadWorkoutDatabase(slug: string) {
  const cached = workoutDatabaseCache.get(slug);
  if (cached) return cached;

  const request = fetch(`${WORKOUT_DATABASE_BASE_URL}/${slug}.json`, { cache: "force-cache" })
    .then((response) => response.ok ? response.json() as Promise<WorkoutDatabaseExercise[]> : null)
    .catch(() => null);
  workoutDatabaseCache.set(slug, request);
  return request;
}

async function loadCandidates(exercise: Exercise) {
  const sourceSlugs = [...new Set(exercise.requiredEquipment.map((item) => workoutEquipmentSources[item]).filter((item): item is string => Boolean(item)))];
  const [exercemus, ...workoutSources] = await Promise.all([
    loadExercemus(),
    ...sourceSlugs.map(loadWorkoutDatabase)
  ]);
  const workoutDatabase = workoutSources.flatMap((source) => source ?? []);
  return buildCandidates(exercemus, workoutDatabase);
}

export async function resolveExternalExerciseVideo(exercise: Exercise): Promise<ResolvedExerciseVideo | null> {
  const candidates = await loadCandidates(exercise);

  let best: { candidate: VideoCandidate; score: number; exact: boolean } | null = null;
  for (const candidate of candidates) {
    const result = scoreCandidate(exercise, candidate);
    if (!best || result.score > best.score) best = { candidate, ...result };
  }

  if (!best || best.score < 48) return null;

  return {
    youtubeId: best.candidate.youtubeId,
    title: best.exact ? `${exercise.name} technique` : `${best.candidate.name} technique reference`,
    channel: best.candidate.channel,
    startSeconds: best.candidate.startSeconds,
    matchType: best.exact ? "exact" : "close"
  };
}
