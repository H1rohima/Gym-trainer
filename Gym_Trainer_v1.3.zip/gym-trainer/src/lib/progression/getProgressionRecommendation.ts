import type { ProgressionRecommendation, SetLog } from "@/types/domain";

export function getProgressionRecommendation(sets: SetLog[], minReps: number, maxReps: number): ProgressionRecommendation {
  const completed = sets.filter((set) => set.completed && set.reps !== null);
  if (completed.length === 0) return "NO_RECOMMENDATION";

  if (completed.every((set) => (set.reps ?? 0) >= maxReps)) return "INCREASE_LOAD";
  if (completed.some((set) => (set.reps ?? 0) < minReps)) return "REDUCE_LOAD";
  return "KEEP_LOAD";
}

export function progressionMessage(recommendation: ProgressionRecommendation): string {
  if (recommendation === "INCREASE_LOAD") return "Increase the weight next time.";
  if (recommendation === "REDUCE_LOAD") return "Use a slightly easier load or variation next time.";
  if (recommendation === "KEEP_LOAD") return "Keep the current load and build reps.";
  return "Complete more sets to get a recommendation.";
}
