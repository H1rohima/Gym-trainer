import type { UserProfile, WorkoutPlan, WorkoutSessionLog } from "@/types/domain";

const keys = {
  profile: "gym-trainer-profile",
  plan: "gym-trainer-plan",
  sessions: "gym-trainer-sessions",
  theme: "gym-trainer-theme"
};

function read<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  const raw = window.localStorage.getItem(key);
  if (!raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function write<T>(key: string, value: T): void {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(key, JSON.stringify(value));
}

export const storage = {
  getProfile: () => read<UserProfile | null>(keys.profile, null),
  setProfile: (profile: UserProfile) => write(keys.profile, profile),
  getPlan: () => read<WorkoutPlan | null>(keys.plan, null),
  setPlan: (plan: WorkoutPlan) => write(keys.plan, plan),
  getSessions: () => read<WorkoutSessionLog[]>(keys.sessions, []),
  setSessions: (sessions: WorkoutSessionLog[]) => write(keys.sessions, sessions),
  addSession: (session: WorkoutSessionLog) => {
    const sessions = read<WorkoutSessionLog[]>(keys.sessions, []);
    write(keys.sessions, [session, ...sessions]);
  },
  getTheme: () => read<"light" | "dark" | "system">(keys.theme, "system"),
  setTheme: (theme: "light" | "dark" | "system") => write(keys.theme, theme),
  clearProgram: () => {
    if (typeof window === "undefined") return;
    window.localStorage.removeItem(keys.plan);
  }
};
