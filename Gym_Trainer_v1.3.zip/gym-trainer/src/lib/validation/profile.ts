import { z } from "zod";
import type { MuscleCode, UserProfile } from "@/types/domain";

const muscleCodes = [
  "CHEST",
  "FRONT_DELTS",
  "SIDE_DELTS",
  "REAR_DELTS",
  "BICEPS",
  "TRICEPS",
  "FOREARMS",
  "ABS",
  "OBLIQUES",
  "UPPER_BACK",
  "LATS",
  "LOWER_BACK",
  "GLUTES",
  "QUADS",
  "HAMSTRINGS",
  "CALVES"
] as const satisfies readonly MuscleCode[];

const equipmentCodes = [
  "BODYWEIGHT",
  "PULL_UP_BAR",
  "DUMBBELL",
  "KETTLEBELL",
  "BARBELL",
  "BENCH",
  "CABLE",
  "MACHINE",
  "BANDS",
  "OTHER"
] as const;

const prioritySchema = z.record(z.string(), z.enum(["LOW", "MEDIUM", "HIGH"])).superRefine((value, context) => {
  const valid = new Set<string>(muscleCodes);
  for (const key of Object.keys(value)) {
    if (!valid.has(key)) context.addIssue({ code: "custom", message: `Unknown muscle code: ${key}` });
  }
});

export const userProfileSchema = z.object({
  goal: z.enum(["HYPERTROPHY", "STRENGTH", "GENERAL_FITNESS"]),
  experience: z.enum(["BEGINNER", "INTERMEDIATE", "ADVANCED"]),
  location: z.enum(["HOME", "GYM"]),
  equipment: z.array(z.enum(equipmentCodes)).max(equipmentCodes.length),
  daysPerWeek: z.union([z.literal(1), z.literal(2), z.literal(3), z.literal(4), z.literal(5), z.literal(6), z.literal(7)]),
  sessionDuration: z.enum(["SHORT", "MEDIUM", "STANDARD", "LONG"]),
  musclePriorities: prioritySchema
}).strict();

export function parseUserProfile(input: unknown): UserProfile {
  return userProfileSchema.parse(input) as UserProfile;
}
