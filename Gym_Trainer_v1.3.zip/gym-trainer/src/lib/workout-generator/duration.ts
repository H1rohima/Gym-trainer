import { ACTIVE_SET_SECONDS, TRANSITION_SECONDS } from "@/config/workout";

export function estimateExerciseMinutes(sets: number, restSeconds: number): number {
  const seconds = sets * ACTIVE_SET_SECONDS + Math.max(0, sets - 1) * restSeconds + TRANSITION_SECONDS;
  return Math.max(1, Math.round(seconds / 60));
}

export function estimateWorkoutMinutes(exercises: Array<{ estimatedMinutes: number }>): number {
  return exercises.reduce((total, exercise) => total + exercise.estimatedMinutes, 0);
}
