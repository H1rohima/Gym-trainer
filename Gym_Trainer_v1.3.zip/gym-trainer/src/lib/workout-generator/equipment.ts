import type { EquipmentCode, Exercise, UserProfile } from "@/types/domain";
import { BASIC_GYM_EQUIPMENT, FULL_GYM_EQUIPMENT } from "@/data/equipment";

export function resolveAvailableEquipment(profile: UserProfile): EquipmentCode[] {
  const available = new Set<EquipmentCode>(["BODYWEIGHT"]);

  if (profile.location === "GYM") {
    const gymPreset = profile.equipment.includes("MACHINE") ? FULL_GYM_EQUIPMENT : BASIC_GYM_EQUIPMENT;
    gymPreset.forEach((item) => available.add(item));
  }

  profile.equipment.forEach((item) => available.add(item));
  return Array.from(available);
}

export function hasRequiredEquipment(exercise: Exercise, available: EquipmentCode[]): boolean {
  const availableSet = new Set(available);
  return exercise.requiredEquipment.every((item) => availableSet.has(item));
}
