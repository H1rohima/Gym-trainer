import type { EquipmentCode, Exercise, UserProfile } from "@/types/domain";
import { hasRequiredEquipment } from "@/lib/workout-generator/equipment";

const difficultyRank = {
  BEGINNER: 1,
  INTERMEDIATE: 2,
  ADVANCED: 3
} as const;

export function filterEligibleExercises(exercises: Exercise[], profile: UserProfile, availableEquipment: EquipmentCode[]): Exercise[] {
  const maxDifficulty = difficultyRank[profile.experience];

  return exercises.filter((exercise) => {
    if (!exercise.active) return false;
    if (!exercise.compatibleLocations.includes(profile.location)) return false;
    if (!exercise.compatibleGoals.includes(profile.goal)) return false;
    if (!hasRequiredEquipment(exercise, availableEquipment)) return false;
    if (difficultyRank[exercise.difficulty] > maxDifficulty) return false;
    return true;
  });
}
