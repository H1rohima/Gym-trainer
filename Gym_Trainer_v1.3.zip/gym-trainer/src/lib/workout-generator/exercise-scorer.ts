import { PRIORITY_WEIGHTS, SCORING } from "@/config/workout";
import type { Exercise, MovementPattern, MuscleCode, UserProfile } from "@/types/domain";

function priorityValue(profile: UserProfile, muscle: MuscleCode): number {
  return PRIORITY_WEIGHTS[profile.musclePriorities[muscle] ?? "MEDIUM"];
}

export function scoreExercise(
  exercise: Exercise,
  focusMuscles: MuscleCode[],
  profile: UserProfile,
  selectedPatterns: MovementPattern[]
): number {
  const focusSet = new Set(focusMuscles);
  let score = 0;

  for (const muscle of exercise.primaryMuscles) {
    if (focusSet.has(muscle)) {
      score += SCORING.primaryMuscle * priorityValue(profile, muscle);
      const priority = profile.musclePriorities[muscle];
      if (priority === "HIGH") score += SCORING.highPriority;
      if (priority === "MEDIUM") score += SCORING.mediumPriority;
      if (priority === "LOW") score += SCORING.lowPriority;
    }
  }

  for (const muscle of exercise.secondaryMuscles) {
    if (focusSet.has(muscle)) score += SCORING.secondaryMuscle * priorityValue(profile, muscle);
  }

  if (exercise.compound) score += SCORING.compound;
  if (!selectedPatterns.includes(exercise.movementPattern)) score += SCORING.movementCoverage;
  if (selectedPatterns.filter((pattern) => pattern === exercise.movementPattern).length >= 2) score -= SCORING.duplicatePatternPenalty;
  if (profile.sessionDuration === "SHORT" && !exercise.compound) score -= SCORING.isolationPenaltyForShortSession;
  score += Math.max(0, 3 - exercise.requiredEquipment.length) * SCORING.equipmentSimplicity;

  return score;
}
