import { BASE_EXERCISE_COUNT, FREQUENCY_EXERCISE_MODIFIER, GENERATOR_VERSION, SCORING, TARGET_MINUTES } from "@/config/workout";
import { EXERCISES } from "@/data/exercises";
import { estimateExerciseMinutes, estimateWorkoutMinutes } from "@/lib/workout-generator/duration";
import { resolveAvailableEquipment } from "@/lib/workout-generator/equipment";
import { filterEligibleExercises } from "@/lib/workout-generator/exercise-filter";
import { scoreExercise } from "@/lib/workout-generator/exercise-scorer";
import { selectSplit } from "@/lib/workout-generator/split-selector";
import { validateGeneratedPlan } from "@/lib/workout-generator/validation";
import type { Exercise, GeneratedExercise, Goal, MuscleCode, UserProfile, WorkoutPlan } from "@/types/domain";

function stableHash(value: string): string {
  let hash = 2166136261;
  for (let index = 0; index < value.length; index += 1) {
    hash ^= value.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return (hash >>> 0).toString(36);
}

function clampRange(min: number, max: number, desiredMin: number, desiredMax: number): [number, number] {
  const nextMin = Math.max(min, desiredMin);
  const nextMax = Math.min(max, desiredMax);
  if (nextMin <= nextMax) return [nextMin, nextMax];
  return [min, max];
}

function prescription(exercise: Exercise, goal: Goal, experience: UserProfile["experience"]): Pick<GeneratedExercise, "sets" | "minReps" | "maxReps" | "restSeconds" | "estimatedMinutes"> {
  let range: [number, number];

  if (goal === "STRENGTH" && exercise.compound) range = clampRange(exercise.defaultMinReps, exercise.defaultMaxReps, 4, 8);
  else if (goal === "HYPERTROPHY") range = clampRange(exercise.defaultMinReps, exercise.defaultMaxReps, 8, 15);
  else range = clampRange(exercise.defaultMinReps, exercise.defaultMaxReps, 8, 15);

  const baseSets = experience === "ADVANCED" ? 4 : 3;
  const sets = Math.min(exercise.defaultMaxSets, Math.max(exercise.defaultMinSets, baseSets));
  const restSeconds = goal === "STRENGTH" && exercise.compound ? Math.max(120, exercise.defaultRestSeconds) : exercise.defaultRestSeconds;
  const estimatedMinutes = estimateExerciseMinutes(sets, restSeconds);

  return { sets, minReps: range[0], maxReps: range[1], restSeconds, estimatedMinutes };
}

function displayMuscle(muscle: MuscleCode): string {
  return muscle.toLowerCase().replaceAll("_", " ").replace(/\b\w/g, (letter) => letter.toUpperCase());
}

function buildReason(exercise: Exercise, profile: UserProfile, focusMuscles: MuscleCode[]): string {
  const prioritized = exercise.primaryMuscles.find((muscle) => profile.musclePriorities[muscle] === "HIGH");
  const focus = exercise.primaryMuscles.find((muscle) => focusMuscles.includes(muscle)) ?? exercise.primaryMuscles[0];
  const equipment = exercise.requiredEquipment.map((item) => item.toLowerCase().replaceAll("_", " ")).join(", ");
  const first = prioritized ? `Targets your high-priority ${displayMuscle(prioritized)} group` : `Targets ${displayMuscle(focus)}`;
  return `${first}, matches your available ${equipment}, and adds a ${exercise.movementPattern.toLowerCase().replaceAll("_", " ")} movement.`;
}

function dayVariation(exerciseId: string, dayIndex: number): number {
  const numericId = Number.parseInt(exerciseId.replace(/\D/g, ""), 10) || 0;
  return ((numericId * 17 + dayIndex * 31) % 29) / 50;
}

function selectExercisesForDay(eligible: Exercise[], focusMuscles: MuscleCode[], profile: UserProfile, dayIndex: number, weeklyUsage: Map<string, number>): GeneratedExercise[] {
  const targetCount = Math.max(4, BASE_EXERCISE_COUNT[profile.sessionDuration] + FREQUENCY_EXERCISE_MODIFIER[profile.daysPerWeek]);
  const selected: Exercise[] = [];

  while (selected.length < targetCount) {
    const selectedIds = new Set(selected.map((exercise) => exercise.id));
    const selectedPatterns = selected.map((exercise) => exercise.movementPattern);
    const candidates = eligible
      .filter((exercise) => !selectedIds.has(exercise.id))
      .map((exercise) => ({ exercise, score: scoreExercise(exercise, focusMuscles, profile, selectedPatterns) + dayVariation(exercise.id, dayIndex) - (weeklyUsage.get(exercise.id) ?? 0) * SCORING.weeklyRepeatPenalty }))
      .filter((item) => item.score > 0)
      .sort((a, b) => b.score - a.score || a.exercise.name.localeCompare(b.exercise.name));

    const next = candidates[0]?.exercise;
    if (!next) break;
    selected.push(next);
  }

  if (selected.length < 4) {
    for (const exercise of eligible.slice().sort((a, b) => Number(b.compound) - Number(a.compound) || a.name.localeCompare(b.name))) {
      if (!selected.some((item) => item.id === exercise.id)) selected.push(exercise);
      if (selected.length >= 4) break;
    }
  }

  let generated = selected.map((exercise, index) => {
    const prescribed = prescription(exercise, profile.goal, profile.experience);
    return {
      exerciseId: exercise.id,
      name: exercise.name,
      order: index + 1,
      ...prescribed,
      primaryMuscles: exercise.primaryMuscles,
      secondaryMuscles: exercise.secondaryMuscles,
      movementPattern: exercise.movementPattern,
      requiredEquipment: exercise.requiredEquipment,
      reason: buildReason(exercise, profile, focusMuscles)
    } satisfies GeneratedExercise;
  });

  const targetMinutes = TARGET_MINUTES[profile.sessionDuration];
  while (generated.length > 4 && estimateWorkoutMinutes(generated) > targetMinutes * 1.25) {
    const removableIndex = [...generated]
      .reverse()
      .findIndex((item) => {
        const original = eligible.find((exercise) => exercise.id === item.exerciseId);
        return original ? !original.compound : false;
      });
    const index = removableIndex >= 0 ? generated.length - 1 - removableIndex : generated.length - 1;
    generated.splice(index, 1);
    generated = generated.map((item, order) => ({ ...item, order: order + 1 }));
  }

  return generated;
}

export function generateWorkoutPlan(profile: UserProfile): WorkoutPlan {
  const availableEquipment = resolveAvailableEquipment(profile);
  const eligible = filterEligibleExercises(EXERCISES, profile, availableEquipment);
  const split = selectSplit(profile);

  if (eligible.length < 4) {
    throw new Error("We couldn't build a valid program with these settings. Review your equipment or training preferences.");
  }

  const weeklyUsage = new Map<string, number>();
  const days = split.map((template, dayIndex) => {
    const exercises = selectExercisesForDay(eligible, template.focusMuscles, profile, dayIndex, weeklyUsage);
    if (exercises.length === 0) throw new Error(`No valid exercises are available for ${template.name}.`);
    for (const exercise of exercises) weeklyUsage.set(exercise.exerciseId, (weeklyUsage.get(exercise.exerciseId) ?? 0) + 1);
    return {
      dayIndex,
      name: template.name,
      focusMuscles: template.focusMuscles,
      estimatedMinutes: estimateWorkoutMinutes(exercises),
      exercises
    };
  });

  const normalizedProfile = JSON.stringify({
    ...profile,
    equipment: [...profile.equipment].sort(),
    musclePriorities: Object.fromEntries(Object.entries(profile.musclePriorities).sort(([left], [right]) => left.localeCompare(right)))
  });
  const plan: WorkoutPlan = {
    id: `plan-${stableHash(`${GENERATOR_VERSION}:${normalizedProfile}`)}`,
    name: `${profile.daysPerWeek}-Day ${profile.goal === "HYPERTROPHY" ? "Muscle Growth" : profile.goal === "STRENGTH" ? "Strength" : "General Fitness"} Program`,
    generatorVersion: GENERATOR_VERSION,
    goal: profile.goal,
    daysPerWeek: profile.daysPerWeek,
    estimatedWeeklyMinutes: days.reduce((total, day) => total + day.estimatedMinutes, 0),
    createdAt: new Date().toISOString(),
    profile,
    days
  };

  const validation = validateGeneratedPlan(plan, availableEquipment);
  if (!validation.valid) throw new Error(validation.errors.join(" "));
  return plan;
}
