import type { MuscleCode, MusclePriority, UserProfile } from "@/types/domain";

export interface SplitDayTemplate {
  name: string;
  focusMuscles: MuscleCode[];
}

const push: MuscleCode[] = ["CHEST", "FRONT_DELTS", "SIDE_DELTS", "TRICEPS"];
const pull: MuscleCode[] = ["LATS", "UPPER_BACK", "REAR_DELTS", "BICEPS", "FOREARMS"];
const legs: MuscleCode[] = ["QUADS", "HAMSTRINGS", "GLUTES", "CALVES"];
const upper: MuscleCode[] = ["CHEST", "FRONT_DELTS", "SIDE_DELTS", "REAR_DELTS", "UPPER_BACK", "LATS", "BICEPS", "TRICEPS", "FOREARMS"];
const lower: MuscleCode[] = ["QUADS", "HAMSTRINGS", "GLUTES", "CALVES", "LOWER_BACK"];
const core: MuscleCode[] = ["ABS", "OBLIQUES"];
const full: MuscleCode[] = [...upper, ...lower, ...core];

function countHighUpper(priorities: Partial<Record<MuscleCode, MusclePriority>>): number {
  return upper.filter((muscle) => priorities[muscle] === "HIGH").length;
}

export function selectSplit(profile: UserProfile): SplitDayTemplate[] {
  if (profile.daysPerWeek === 1) {
    return [{ name: "Full Body", focusMuscles: full }];
  }

  if (profile.daysPerWeek === 2) {
    return [
      { name: "Full Body A", focusMuscles: full },
      { name: "Full Body B", focusMuscles: full }
    ];
  }

  if (profile.daysPerWeek === 3) {
    if (countHighUpper(profile.musclePriorities) >= 3) {
      return [
        { name: "Upper", focusMuscles: upper },
        { name: "Lower + Core", focusMuscles: [...lower, ...core] },
        { name: "Full Body", focusMuscles: full }
      ];
    }

    return [
      { name: "Full Body A", focusMuscles: full },
      { name: "Full Body B", focusMuscles: full },
      { name: "Full Body C", focusMuscles: full }
    ];
  }

  if (profile.daysPerWeek === 4) {
    return [
      { name: "Upper A", focusMuscles: upper },
      { name: "Lower A", focusMuscles: [...lower, ...core] },
      { name: "Upper B", focusMuscles: upper },
      { name: "Lower B", focusMuscles: [...lower, ...core] }
    ];
  }

  if (profile.daysPerWeek === 5) {
    return [
      { name: "Push", focusMuscles: push },
      { name: "Pull", focusMuscles: pull },
      { name: "Legs", focusMuscles: legs },
      { name: "Upper", focusMuscles: upper },
      { name: "Lower + Core", focusMuscles: [...lower, ...core] }
    ];
  }

  if (profile.daysPerWeek === 6) {
    return [
      { name: "Push A", focusMuscles: push },
      { name: "Pull A", focusMuscles: pull },
      { name: "Legs A", focusMuscles: [...legs, ...core] },
      { name: "Push B", focusMuscles: push },
      { name: "Pull B", focusMuscles: pull },
      { name: "Legs B", focusMuscles: [...legs, ...core] }
    ];
  }

  return [
    { name: "Push", focusMuscles: push },
    { name: "Pull", focusMuscles: pull },
    { name: "Legs", focusMuscles: legs },
    { name: "Upper", focusMuscles: upper },
    { name: "Lower + Core", focusMuscles: [...lower, ...core] },
    { name: "Full Body A", focusMuscles: full },
    { name: "Full Body B", focusMuscles: full }
  ];
}
