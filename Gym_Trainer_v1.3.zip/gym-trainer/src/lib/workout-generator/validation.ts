import type { EquipmentCode, WorkoutPlan } from "@/types/domain";

export interface ValidationResult {
  valid: boolean;
  errors: string[];
}

export function validateGeneratedPlan(plan: WorkoutPlan, availableEquipment: EquipmentCode[]): ValidationResult {
  const errors: string[] = [];
  const equipment = new Set(availableEquipment);

  if (plan.days.length !== plan.daysPerWeek) errors.push("Workout day count does not match the selected frequency.");

  for (const day of plan.days) {
    if (day.exercises.length === 0) errors.push(`${day.name} has no exercises.`);
    const ids = day.exercises.map((exercise) => exercise.exerciseId);
    if (new Set(ids).size !== ids.length) errors.push(`${day.name} contains a duplicate exercise.`);

    for (const exercise of day.exercises) {
      if (!exercise.requiredEquipment.every((item) => equipment.has(item))) {
        errors.push(`${exercise.name} requires unavailable equipment.`);
      }
      if (exercise.sets < 1 || exercise.minReps < 1 || exercise.maxReps < exercise.minReps) {
        errors.push(`${exercise.name} has an invalid prescription.`);
      }
    }
  }

  return { valid: errors.length === 0, errors };
}
