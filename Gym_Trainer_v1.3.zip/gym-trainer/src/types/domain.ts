export type Goal = "HYPERTROPHY" | "STRENGTH" | "GENERAL_FITNESS";
export type Experience = "BEGINNER" | "INTERMEDIATE" | "ADVANCED";
export type TrainingLocation = "HOME" | "GYM";
export type MusclePriority = "LOW" | "MEDIUM" | "HIGH";
export type SessionDuration = "SHORT" | "MEDIUM" | "STANDARD" | "LONG";
export type Difficulty = Experience;
export type MuscleRole = "PRIMARY" | "SECONDARY";
export type ProgressionRecommendation = "KEEP_LOAD" | "INCREASE_LOAD" | "REDUCE_LOAD" | "NO_RECOMMENDATION";

export type MuscleCode =
  | "CHEST"
  | "FRONT_DELTS"
  | "SIDE_DELTS"
  | "REAR_DELTS"
  | "BICEPS"
  | "TRICEPS"
  | "FOREARMS"
  | "ABS"
  | "OBLIQUES"
  | "UPPER_BACK"
  | "LATS"
  | "LOWER_BACK"
  | "GLUTES"
  | "QUADS"
  | "HAMSTRINGS"
  | "CALVES";

export type EquipmentCode =
  | "BODYWEIGHT"
  | "PULL_UP_BAR"
  | "DUMBBELL"
  | "KETTLEBELL"
  | "BARBELL"
  | "BENCH"
  | "CABLE"
  | "MACHINE"
  | "BANDS"
  | "OTHER";

export type MovementPattern =
  | "HORIZONTAL_PUSH"
  | "VERTICAL_PUSH"
  | "HORIZONTAL_PULL"
  | "VERTICAL_PULL"
  | "SQUAT"
  | "HINGE"
  | "LUNGE"
  | "ELBOW_FLEXION"
  | "ELBOW_EXTENSION"
  | "SHOULDER_ABDUCTION"
  | "SHOULDER_EXTENSION"
  | "CORE_FLEXION"
  | "CORE_STABILITY"
  | "CORE_ROTATION"
  | "CARRY"
  | "CALF_RAISE";

export interface Exercise {
  id: string;
  slug: string;
  name: string;
  description: string;
  instructions: string[];
  tips: string[];
  difficulty: Difficulty;
  movementPattern: MovementPattern;
  unilateral: boolean;
  compound: boolean;
  active: boolean;
  primaryMuscles: MuscleCode[];
  secondaryMuscles: MuscleCode[];
  requiredEquipment: EquipmentCode[];
  compatibleGoals: Goal[];
  compatibleLocations: TrainingLocation[];
  defaultMinSets: number;
  defaultMaxSets: number;
  defaultMinReps: number;
  defaultMaxReps: number;
  defaultRestSeconds: number;
}

export interface UserProfile {
  goal: Goal;
  experience: Experience;
  location: TrainingLocation;
  equipment: EquipmentCode[];
  daysPerWeek: 1 | 2 | 3 | 4 | 5 | 6 | 7;
  sessionDuration: SessionDuration;
  musclePriorities: Partial<Record<MuscleCode, MusclePriority>>;
}

export interface GeneratedExercise {
  exerciseId: string;
  name: string;
  order: number;
  sets: number;
  minReps: number;
  maxReps: number;
  restSeconds: number;
  estimatedMinutes: number;
  primaryMuscles: MuscleCode[];
  secondaryMuscles: MuscleCode[];
  movementPattern: MovementPattern;
  requiredEquipment: EquipmentCode[];
  reason: string;
}

export interface WorkoutDay {
  dayIndex: number;
  name: string;
  focusMuscles: MuscleCode[];
  estimatedMinutes: number;
  exercises: GeneratedExercise[];
}

export interface WorkoutPlan {
  id: string;
  name: string;
  generatorVersion: string;
  goal: Goal;
  daysPerWeek: number;
  estimatedWeeklyMinutes: number;
  createdAt: string;
  profile: UserProfile;
  days: WorkoutDay[];
}

export interface SetLog {
  setNumber: number;
  weight: number | null;
  reps: number | null;
  completed: boolean;
}

export interface ExerciseLog {
  exerciseId: string;
  exerciseName: string;
  targetMinReps: number;
  targetMaxReps: number;
  sets: SetLog[];
}

export interface WorkoutSessionLog {
  id: string;
  planId: string;
  dayIndex: number;
  dayName: string;
  startedAt: string;
  completedAt: string | null;
  durationSeconds: number;
  exercises: ExerciseLog[];
}
