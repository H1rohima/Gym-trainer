import { describe, expect, it } from "vitest";
import { generateWorkoutPlan } from "@/lib/workout-generator/generator";
import type { UserProfile } from "@/types/domain";

const scenarios: Array<{ name: string; profile: UserProfile }> = [
  { name: "home one day", profile: { goal: "GENERAL_FITNESS", experience: "BEGINNER", location: "HOME", equipment: [], daysPerWeek: 1, sessionDuration: "STANDARD", musclePriorities: {} } },
  { name: "home no equipment", profile: { goal: "GENERAL_FITNESS", experience: "BEGINNER", location: "HOME", equipment: [], daysPerWeek: 3, sessionDuration: "MEDIUM", musclePriorities: {} } },
  { name: "home dumbbells", profile: { goal: "HYPERTROPHY", experience: "INTERMEDIATE", location: "HOME", equipment: ["DUMBBELL"], daysPerWeek: 3, sessionDuration: "STANDARD", musclePriorities: { CHEST: "HIGH", QUADS: "MEDIUM" } } },
  { name: "home dumbbells and pull-up bar", profile: { goal: "HYPERTROPHY", experience: "INTERMEDIATE", location: "HOME", equipment: ["DUMBBELL", "PULL_UP_BAR"], daysPerWeek: 4, sessionDuration: "STANDARD", musclePriorities: { CHEST: "HIGH", LATS: "HIGH" } } },
  { name: "home kettlebell", profile: { goal: "GENERAL_FITNESS", experience: "INTERMEDIATE", location: "HOME", equipment: ["KETTLEBELL"], daysPerWeek: 3, sessionDuration: "MEDIUM", musclePriorities: {} } },
  { name: "full gym hypertrophy", profile: { goal: "HYPERTROPHY", experience: "INTERMEDIATE", location: "GYM", equipment: ["MACHINE", "CABLE", "DUMBBELL", "BARBELL", "BENCH"], daysPerWeek: 4, sessionDuration: "STANDARD", musclePriorities: { CHEST: "HIGH", LATS: "HIGH" } } },
  { name: "full gym strength", profile: { goal: "STRENGTH", experience: "INTERMEDIATE", location: "GYM", equipment: ["MACHINE", "CABLE", "DUMBBELL", "BARBELL", "BENCH"], daysPerWeek: 3, sessionDuration: "LONG", musclePriorities: {} } },
  { name: "full gym six days", profile: { goal: "HYPERTROPHY", experience: "INTERMEDIATE", location: "GYM", equipment: ["MACHINE", "CABLE", "DUMBBELL", "BARBELL", "BENCH"], daysPerWeek: 6, sessionDuration: "MEDIUM", musclePriorities: { CHEST: "HIGH", LATS: "HIGH" } } },
  { name: "full gym seven days", profile: { goal: "GENERAL_FITNESS", experience: "INTERMEDIATE", location: "GYM", equipment: ["MACHINE", "CABLE", "DUMBBELL", "BARBELL", "BENCH"], daysPerWeek: 7, sessionDuration: "SHORT", musclePriorities: {} } }
];

describe("exercise database coverage", () => {
  it.each(scenarios)("generates a valid plan for $name", ({ profile }) => {
    const plan = generateWorkoutPlan(profile);
    expect(plan.days).toHaveLength(profile.daysPerWeek);
    expect(plan.days.every((day) => day.exercises.length >= 4)).toBe(true);
  });
});
