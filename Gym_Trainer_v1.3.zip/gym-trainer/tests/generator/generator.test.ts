import { describe, expect, it } from "vitest";
import { generateWorkoutPlan } from "@/lib/workout-generator/generator";
import { resolveAvailableEquipment } from "@/lib/workout-generator/equipment";
import type { UserProfile } from "@/types/domain";

const baseProfile: UserProfile = {
  goal: "HYPERTROPHY",
  experience: "INTERMEDIATE",
  location: "HOME",
  equipment: ["DUMBBELL", "PULL_UP_BAR"],
  daysPerWeek: 3,
  sessionDuration: "STANDARD",
  musclePriorities: { CHEST: "HIGH", LATS: "HIGH", SIDE_DELTS: "MEDIUM" }
};

describe("workout generator", () => {
  it("is deterministic for the same profile", () => {
    const first = generateWorkoutPlan(baseProfile);
    const second = generateWorkoutPlan(baseProfile);
    expect(first.days).toEqual(second.days);
    expect(first.id).toBe(second.id);
  });

  it("changes the plan identity when nested muscle priorities change", () => {
    const first = generateWorkoutPlan(baseProfile);
    const second = generateWorkoutPlan({ ...baseProfile, musclePriorities: { ...baseProfile.musclePriorities, CHEST: "LOW" } });
    expect(first.id).not.toBe(second.id);
  });

  it("creates deterministic variation across three full-body days", () => {
    const plan = generateWorkoutPlan({ ...baseProfile, equipment: ["DUMBBELL"], musclePriorities: { CHEST: "HIGH" } });
    const signatures = plan.days.map((day) => day.exercises.map((exercise) => exercise.exerciseId).join(","));
    expect(new Set(signatures).size).toBe(plan.days.length);
  });

  it("never selects unavailable required equipment", () => {
    const profile: UserProfile = { ...baseProfile, equipment: ["DUMBBELL"] };
    const available = new Set(resolveAvailableEquipment(profile));
    const plan = generateWorkoutPlan(profile);
    for (const day of plan.days) {
      for (const exercise of day.exercises) {
        expect(exercise.requiredEquipment.every((item) => available.has(item))).toBe(true);
      }
    }
  });

  it("supports a no-equipment home profile", () => {
    const plan = generateWorkoutPlan({
      ...baseProfile,
      goal: "GENERAL_FITNESS",
      experience: "BEGINNER",
      equipment: [],
      daysPerWeek: 3,
      musclePriorities: {}
    });
    expect(plan.days).toHaveLength(3);
    expect(plan.days.every((day) => day.exercises.length >= 4)).toBe(true);
    expect(plan.days.flatMap((day) => day.exercises).every((exercise) => exercise.requiredEquipment.every((item) => item === "BODYWEIGHT"))).toBe(true);
  });

  it("creates smaller short sessions than long sessions", () => {
    const shortPlan = generateWorkoutPlan({ ...baseProfile, sessionDuration: "SHORT" });
    const longPlan = generateWorkoutPlan({ ...baseProfile, sessionDuration: "LONG" });
    const shortCount = shortPlan.days.reduce((total, day) => total + day.exercises.length, 0);
    const longCount = longPlan.days.reduce((total, day) => total + day.exercises.length, 0);
    expect(shortCount).toBeLessThan(longCount);
  });

  it("does not give advanced exercises to beginners", () => {
    const plan = generateWorkoutPlan({ ...baseProfile, experience: "BEGINNER" });
    const advancedNames = new Set(["Hanging Leg Raise", "Bodyweight Sissy Squat", "Kettlebell Clean", "Front Squat"]);
    expect(plan.days.flatMap((day) => day.exercises).some((exercise) => advancedNames.has(exercise.name))).toBe(false);
  });

  it.each([1, 2, 3, 4, 5, 6, 7] as const)("creates the requested %i-day split", (daysPerWeek) => {
    const plan = generateWorkoutPlan({ ...baseProfile, daysPerWeek });
    expect(plan.days).toHaveLength(daysPerWeek);
    expect(plan.days.every((day) => day.exercises.length > 0)).toBe(true);
  });
});
