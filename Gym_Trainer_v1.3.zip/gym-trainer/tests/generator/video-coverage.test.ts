import { describe, expect, it } from "vitest";
import { EXERCISES } from "@/data/exercises";

function youtubeSearchUrl(name: string) {
  return `https://www.youtube.com/results?search_query=${encodeURIComponent(`${name} exercise tutorial proper form`)}`;
}

describe("exercise video coverage", () => {
  it("provides a deterministic YouTube backup for every exercise", () => {
    expect(EXERCISES).toHaveLength(134);
    EXERCISES.forEach((exercise) => {
      expect(youtubeSearchUrl(exercise.name)).toContain("youtube.com/results?search_query=");
    });
  });
});
