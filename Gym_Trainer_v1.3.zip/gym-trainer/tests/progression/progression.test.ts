import { describe, expect, it } from "vitest";
import { getProgressionRecommendation } from "@/lib/progression/getProgressionRecommendation";

const sets = (reps: number[]) => reps.map((value, index) => ({ setNumber: index + 1, weight: 20, reps: value, completed: true }));

describe("double progression", () => {
  it("recommends increasing load after all sets reach the top of the range", () => {
    expect(getProgressionRecommendation(sets([12, 12, 12]), 8, 12)).toBe("INCREASE_LOAD");
  });

  it("keeps load when completed sets remain inside the target range", () => {
    expect(getProgressionRecommendation(sets([11, 10, 9]), 8, 12)).toBe("KEEP_LOAD");
  });

  it("recommends reducing load when a completed set falls below the minimum", () => {
    expect(getProgressionRecommendation(sets([9, 8, 6]), 8, 12)).toBe("REDUCE_LOAD");
  });
});
